/* nes_memory.c - CPU bus slow paths (PPU/APU/IO registers, PRG-RAM, mapper writes) */
#include "nes.h"

uint8_t nes_read_slow(Nes *n, uint16_t a) {
    if (a < 0x4000) return ppu_reg_read(n, a & 7);
    if (a < 0x4020) {
        if (a == 0x4015) return apu_read_status(n);
        if (a == 0x4016) {
            uint8_t r = (uint8_t)((n->joy_strobe ? (n->joy_buttons & 1) : (n->joy_shift & 1)) | 0x40);
            if (!n->joy_strobe) n->joy_shift = (uint8_t)((n->joy_shift >> 1) | 0x80);
            return r;
        }
        return 0x40;
    }
    if (a >= 0x6000 && a < 0x8000) return n->prg_ram[a & 0x1FFF];
    return 0;
}

void nes_write_slow(Nes *n, uint16_t a, uint8_t v) {
    if (a < 0x4000) { ppu_reg_write(n, a & 7, v); return; }
    if (a < 0x4020) {
        if (a == 0x4014) {
            uint16_t base = (uint16_t)(v << 8);
            for (int i = 0; i < 256; i++) n->ppu.oam[(uint8_t)(n->ppu.oam_addr + i)] = nes_read(n, (uint16_t)(base + i));
            int st = 513 + (int)(n->cpu.cycles & 1);
            n->cpu.cycles += st;
            n->ppu.dot += (int16_t)(st * 3);
        } else if (a == 0x4016) {
            n->joy_strobe = v & 1;
            if (n->joy_strobe) n->joy_shift = n->joy_buttons;
        } else apu_write(n, a, v);
        return;
    }
    if (a < 0x6000) return;
    if (a < 0x8000) { n->prg_ram[a & 0x1FFF] = v; return; }
    if (n->mapper) n->mapper->write(n, a, v);
}
