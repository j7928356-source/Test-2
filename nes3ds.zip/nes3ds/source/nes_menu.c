/* nes_menu.c - bottom-screen UI (libctru console), ROM browser, settings, config file */
#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include "nes_menu.h"

#define CFG_PATH  "sdmc:/3ds/nes3ds/config.bin"
#define CFG_MAGIC 0x4E335343u
#define MAX_ROMS  1024
#define NAME_LEN  128
#define ROWS      23

/* ---------------- config ---------------- */
void config_defaults(Config *c) {
    memset(c, 0, sizeof *c);
    c->magic = CFG_MAGIC; c->scale = SCALE_1X; c->frameskip = 1; c->audio = 1;
    c->lmap = BTN_TURBO_B; c->rmap = BTN_TURBO_A; c->showfps = 0;
}
void config_load(Config *c) {
    config_defaults(c);
    FILE *f = fopen(CFG_PATH, "rb");
    if (!f) return;
    Config t;
    if (fread(&t, sizeof t, 1, f) == 1 && t.magic == CFG_MAGIC && t.scale < SCALE_COUNT &&
        t.lmap < BTN_COUNT && t.rmap < BTN_COUNT && t.nrecent <= MAX_RECENT) {
        for (int i = 0; i < MAX_RECENT; i++) t.recent[i][255] = 0;
        *c = t;
    }
    fclose(f);
}
void config_save(const Config *c) {
    FILE *f = fopen(CFG_PATH, "wb");
    if (f) { fwrite(c, sizeof *c, 1, f); fclose(f); }
}
void recent_add(Config *c, const char *path) {
    int idx = c->nrecent;
    for (int i = 0; i < c->nrecent; i++) if (!strcmp(c->recent[i], path)) { idx = i; break; }
    if (idx == c->nrecent) { if (c->nrecent < MAX_RECENT) c->nrecent++; idx = c->nrecent - 1; }
    for (int i = idx; i > 0; i--) memcpy(c->recent[i], c->recent[i - 1], 256);
    snprintf(c->recent[0], 256, "%s", path);
}

/* ---------------- input helpers ---------------- */
static u32 pressed(void) {
    static int rep;
    const u32 dirs = KEY_DUP | KEY_DDOWN | KEY_DLEFT | KEY_DRIGHT;
    u32 d = hidKeysDown(), h = hidKeysHeld(), r = d;
    if (d & dirs) rep = 0;
    else if (h & dirs) { if (++rep > 20 && (rep & 3) == 0) r |= h & dirs; }
    else rep = 0;
    return r;
}
/* one frame of menu loop; returns false if the app should quit */
static bool tick(void) {
    gfxFlushBuffers(); gfxSwapBuffers(); gspWaitForVBlank();
    if (!aptMainLoop()) return false;
    hidScanInput();
    return true;
}

static void header(const char *t) {
    consoleClear();
    printf("\x1b[1;1H\x1b[33;1m %s\x1b[0m\n ----------------------------------------\n", t);
}
static void footer(const char *s) { printf("\x1b[29;1H\x1b[36m %s\x1b[0m", s); }

/* generic vertical list; returns chosen index, -2 for back, -1 for quit */
static int run_list(const char *title, const char **items, int count, int sel0, const char *foot) {
    int sel = sel0, top = 0, redraw = 1;
    hidScanInput();
    for (;;) {
        u32 k = pressed();
        if (k & KEY_DUP) { sel = (sel + count - 1) % count; redraw = 1; }
        if (k & KEY_DDOWN) { sel = (sel + 1) % count; redraw = 1; }
        if (k & KEY_DLEFT) { sel -= ROWS; if (sel < 0) sel = 0; redraw = 1; }
        if (k & KEY_DRIGHT) { sel += ROWS; if (sel >= count) sel = count - 1; redraw = 1; }
        if (k & KEY_A) return sel;
        if (k & KEY_B) return -2;
        if (redraw) {
            if (sel < top) top = sel;
            if (sel >= top + ROWS) top = sel - ROWS + 1;
            header(title);
            for (int i = top; i < count && i < top + ROWS; i++)
                printf("%s %-37.37s\x1b[0m\n", i == sel ? "\x1b[32;1m>" : " ", items[i]);
            footer(foot);
            redraw = 0;
        }
        if (!tick()) return -1;
    }
}

/* ---------------- screens ---------------- */
int menu_main(void) {
    static const char *items[] = {"Load Game", "Recent Games", "Settings", "About", "Exit"};
    int r = run_list("NES EMULATOR for Nintendo 3DS", items, 5, 0, "D-Pad: move   A: select   B: exit");
    return r == -2 ? MAIN_EXIT : r < 0 ? -1 : r;
}

static char names[MAX_ROMS][NAME_LEN];
static const char *name_ptrs[MAX_ROMS];
static int cmp_names(const void *a, const void *b) { return strcasecmp((const char *)a, (const char *)b); }

static int scan_roms(void) {
    int n = 0;
    DIR *d = opendir(ROM_DIR);
    if (!d) return 0;
    struct dirent *e;
    while ((e = readdir(d)) && n < MAX_ROMS) {
        size_t l = strlen(e->d_name);
        if (e->d_name[0] == '.' || l < 5 || l >= NAME_LEN || strcasecmp(e->d_name + l - 4, ".nes")) continue;
        strcpy(names[n++], e->d_name);
    }
    closedir(d);
    qsort(names, (size_t)n, NAME_LEN, cmp_names);
    return n;
}

int menu_browser(char *out, size_t cap) {
    int n = scan_roms();
    if (n == 0) {
        menu_message("No ROMs found", "Copy .nes files to\nsdmc:/roms/nes/ on your SD card.");
        return 0;
    }
    for (int i = 0; i < n; i++) name_ptrs[i] = names[i];
    char title[48]; snprintf(title, sizeof title, "Game Browser (%d games)", n);
    int r = run_list(title, name_ptrs, n, 0, "A: play   B: back   Left/Right: page");
    if (r == -1) return -1;
    if (r < 0) return 0;
    snprintf(out, cap, "%s/%s", ROM_DIR, names[r]);
    return 1;
}

int menu_recent(const Config *cfg, char *out, size_t cap) {
    if (cfg->nrecent == 0) { menu_message("Recent Games", "No games played yet."); return 0; }
    const char *items[MAX_RECENT];
    for (int i = 0; i < cfg->nrecent; i++) {
        const char *b = strrchr(cfg->recent[i], '/');
        items[i] = b ? b + 1 : cfg->recent[i];
    }
    int r = run_list("Recent Games", items, cfg->nrecent, 0, "A: play   B: back");
    if (r == -1) return -1;
    if (r < 0) return 0;
    snprintf(out, cap, "%s", cfg->recent[r]);
    return 1;
}

static const char *btn_names[BTN_COUNT] = {"None", "A", "B", "Select", "Start", "Turbo A", "Turbo B"};
static const char *scale_names[SCALE_COUNT] = {"1:1 (256x240, centered)", "NES aspect 8:7 (292x240)", "Full width (400x240)"};

void menu_settings(Config *c) {
    int sel = 0, redraw = 1; const int N = 6;
    hidScanInput();
    for (;;) {
        u32 k = pressed();
        if (k & KEY_DUP) { sel = (sel + N - 1) % N; redraw = 1; }
        if (k & KEY_DDOWN) { sel = (sel + 1) % N; redraw = 1; }
        int d = (k & KEY_DRIGHT) ? 1 : (k & KEY_DLEFT) ? -1 : (k & KEY_A) ? 1 : 0;
        if (d) {
            switch (sel) {
            case 0: c->scale = (uint8_t)((c->scale + SCALE_COUNT + d) % SCALE_COUNT); break;
            case 1: c->frameskip ^= 1; break;
            case 2: c->audio ^= 1; break;
            case 3: c->lmap = (uint8_t)((c->lmap + BTN_COUNT + d) % BTN_COUNT); break;
            case 4: c->rmap = (uint8_t)((c->rmap + BTN_COUNT + d) % BTN_COUNT); break;
            case 5: c->showfps ^= 1; break;
            }
            redraw = 1;
        }
        if (k & KEY_B) { config_save(c); return; }
        if (redraw) {
            const char *v[6];
            v[0] = scale_names[c->scale]; v[1] = c->frameskip ? "Auto" : "Off"; v[2] = c->audio ? "On" : "Off";
            v[3] = btn_names[c->lmap]; v[4] = btn_names[c->rmap]; v[5] = c->showfps ? "On" : "Off";
            static const char *lbl[6] = {"Screen", "Frameskip", "Audio", "L button", "R button", "Show FPS"};
            header("Settings");
            for (int i = 0; i < N; i++)
                printf("%s %-11s %-24.24s\x1b[0m\n\n", i == sel ? "\x1b[32;1m>" : " ", lbl[i], v[i]);
            printf("\n D-Pad: NES D-Pad   A/B: NES A/B\n X: Select   Y: Start   START: menu\n");
            footer("Left/Right: change   B: save & back");
            redraw = 0;
        }
        if (!tick()) return;
    }
}

void menu_message(const char *title, const char *msg) {
    hidScanInput();
    header(title);
    printf("\n %s\n", msg);
    footer("Press A");
    for (;;) {
        if (!tick()) return;
        if (hidKeysDown() & (KEY_A | KEY_B)) return;
    }
}

void menu_about(void) {
    menu_message("About",
        "NES Emulator for Nintendo 3DS\n"
        " 6502 CPU, scanline PPU, full APU\n"
        " Mappers: 0 NROM, 1 MMC1, 2 UxROM,\n"
        " 3 CNROM, 4 MMC3, 7 AxROM\n\n"
        " ROMs:   sdmc:/roms/nes/*.nes\n"
        " Saves:  sdmc:/3ds/nes3ds/states/\n"
        " Audio needs sdmc:/3ds/dspfirm.cdc\n\n"
        " In game: START opens the menu\n"
        " D-Pad/A/B = pad, X=Select, Y=Start");
}

int menu_pause(const char *status) {
    static const char *items[] = {"Resume", "Save State", "Load State", "Reset Game", "Return to Game Browser", "Exit Emulator"};
    int sel = 0, redraw = 1;
    hidScanInput();
    for (;;) {
        u32 k = pressed();
        if (k & KEY_DUP) { sel = (sel + 5) % 6; redraw = 1; }
        if (k & KEY_DDOWN) { sel = (sel + 1) % 6; redraw = 1; }
        if (k & (KEY_A)) return sel;
        if (k & (KEY_B | KEY_START)) return PAUSE_RESUME;
        if (redraw) {
            header("Paused");
            for (int i = 0; i < 6; i++) printf("%s %-37.37s\x1b[0m\n\n", i == sel ? "\x1b[32;1m>" : " ", items[i]);
            if (status && *status) printf("\n \x1b[33m%s\x1b[0m\n", status);
            footer("A: select   B/START: resume");
            redraw = 0;
        }
        if (!tick()) return PAUSE_EXIT;
    }
}
