/* nes_apu.c - 2A03 APU: 2 pulse, triangle, noise, DMC, frame counter.
 * Channels are advanced in batches between sample points; output is 2x oversampled
 * (averaged) mono 32 kHz with a DC-blocking filter. */
#include "nes.h"
#include <string.h>

#define OS 2
#define SUB_STEP ((CPU_HZ * 256) / (AUDIO_RATE * OS))

static const uint8_t len_tab[32] = {10,254,20,2,40,4,80,6,160,8,60,10,14,12,26,14,12,16,24,18,48,20,96,22,192,24,72,26,16,28,32,30};
static const uint16_t noise_tab[16] = {4,8,16,32,64,96,128,160,202,254,380,508,762,1016,2034,4068};
static const uint16_t dmc_tab[16] = {428,380,340,320,286,254,226,214,190,160,142,128,106,84,72,54};
static const uint8_t duty_tab[4][8] = {{0,1,0,0,0,0,0,0},{0,1,1,0,0,0,0,0},{0,1,1,1,1,0,0,0},{1,0,0,1,1,1,1,1}};
static const uint8_t tri_tab[32] = {15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
static const int fc4[4] = {7457, 14913, 22371, 29830};
static const int fc5[5] = {7457, 14913, 22371, 29829, 37282};
static int32_t pulse_mix[31], tnd_mix[203];

void apu_init(void) {
    for (int i = 0; i < 31; i++) pulse_mix[i] = i ? (int32_t)(24000.0 * 95.52 / (8128.0 / i + 100.0)) : 0;
    for (int i = 0; i < 203; i++) tnd_mix[i] = i ? (int32_t)(24000.0 * 163.67 / (24329.0 / i + 100.0)) : 0;
}

void apu_reset(Nes *n) {
    Apu *a = &n->apu;
    memset(a, 0, sizeof *a);
    a->p[1].ch = 1; a->n.lfsr = 1; a->n.period = noise_tab[0];
    a->d_rate = dmc_tab[0]; a->d_cnt = a->d_rate; a->d_bits = 8; a->d_silence = 1; a->d_empty = 1;
    a->d_addr_start = 0xC000; a->d_addr = 0xC000;
    a->sub_cnt = SUB_STEP; a->t.period = 0;
    n->apu_cyc = 0;
}

/* ---- envelope / length / sweep helpers ---- */
static void env_clock(uint8_t *start, uint8_t *div, uint8_t *decay, uint8_t vol, uint8_t loop) {
    if (*start) { *start = 0; *decay = 15; *div = vol; }
    else if (*div == 0) { *div = vol; if (*decay) (*decay)--; else if (loop) *decay = 15; }
    else (*div)--;
}
static int sweep_target(const Pulse *p) {
    int ch = p->period >> p->swshift;
    return p->swneg ? p->period - ch - (p->ch ? 0 : 1) : p->period + ch;
}
static int sweep_mute(const Pulse *p) { return p->period < 8 || (!p->swneg && sweep_target(p) > 0x7FF); }

static void clock_quarter(Apu *a) {
    for (int i = 0; i < 2; i++) env_clock(&a->p[i].estart, &a->p[i].ediv, &a->p[i].edecay, a->p[i].vol, a->p[i].halt);
    env_clock(&a->n.estart, &a->n.ediv, &a->n.edecay, a->n.vol, a->n.halt);
    if (a->t.linreload) a->t.lin = a->t.linper; else if (a->t.lin) a->t.lin--;
    if (!a->t.ctrl) a->t.linreload = 0;
}
static void clock_half(Apu *a) {
    for (int i = 0; i < 2; i++) {
        Pulse *p = &a->p[i];
        if (!p->halt && p->len) p->len--;
        if (p->swdiv == 0 && p->swen && p->swshift && !sweep_mute(p)) p->period = (uint16_t)sweep_target(p);
        if (p->swdiv == 0 || p->swreload) { p->swdiv = p->swper; p->swreload = 0; } else p->swdiv--;
    }
    if (!a->t.ctrl && a->t.len) a->t.len--;
    if (!a->n.halt && a->n.len) a->n.len--;
}

/* ---- DMC ---- */
static void dmc_start(Apu *a) { a->d_addr = a->d_addr_start; a->d_bytes = a->d_len_start; }
static void dmc_fetch(Nes *n) {
    Apu *a = &n->apu;
    if (a->d_empty && a->d_bytes > 0) {
        a->d_buf = nes_read(n, a->d_addr); a->d_empty = 0;
        a->d_addr = (uint16_t)((a->d_addr + 1) | 0x8000);
        if (--a->d_bytes == 0) { if (a->d_loop) dmc_start(a); else if (a->d_irq_en) a->dmc_irq = 1; }
    }
}
static void dmc_step(Nes *n) {
    Apu *a = &n->apu;
    if (!a->d_silence) {
        if (a->d_shift & 1) { if (a->d_level <= 125) a->d_level += 2; }
        else if (a->d_level >= 2) a->d_level -= 2;
        a->d_shift >>= 1;
    }
    if (--a->d_bits == 0) {
        a->d_bits = 8;
        if (a->d_empty) a->d_silence = 1;
        else { a->d_silence = 0; a->d_shift = a->d_buf; a->d_empty = 1; dmc_fetch(n); }
    }
}

/* ---- timers ---- */
static void advance(Nes *n, int cy) {
    Apu *a = &n->apu; int c, per, steps;
    for (int i = 0; i < 2; i++) {
        Pulse *p = &a->p[i];
        if (p->cnt > cy) { p->cnt -= cy; continue; }
        c = cy - p->cnt; per = (p->period + 1) * 2; steps = 1;
        while (c >= per) { c -= per; steps++; }
        p->cnt = per - c; p->seq = (uint8_t)((p->seq + steps) & 7);
    }
    {
        Tri *t = &a->t;
        if (t->cnt > cy) t->cnt -= cy;
        else {
            c = cy - t->cnt; per = t->period + 1; steps = 1;
            while (c >= per) { c -= per; steps++; }
            t->cnt = per - c;
            if (t->len && t->lin) t->seq = (uint8_t)((t->seq + steps) & 31);
        }
    }
    {
        Noise *nz = &a->n;
        if (nz->cnt > cy) nz->cnt -= cy;
        else {
            c = cy - nz->cnt; per = nz->period; steps = 1;
            while (c >= per) { c -= per; steps++; }
            nz->cnt = per - c;
            while (steps--) {
                uint16_t fb = (uint16_t)((nz->lfsr & 1) ^ ((nz->lfsr >> (nz->mode ? 6 : 1)) & 1));
                nz->lfsr = (uint16_t)((nz->lfsr >> 1) | (fb << 14));
            }
        }
    }
    if (a->d_cnt > cy) a->d_cnt -= cy;
    else {
        c = cy - a->d_cnt; per = a->d_rate; steps = 1;
        while (c >= per) { c -= per; steps++; }
        a->d_cnt = per - c;
        while (steps--) dmc_step(n);
    }
}

static int pulse_out(const Pulse *p) {
    if (!p->len || !duty_tab[p->duty][p->seq] || sweep_mute(p)) return 0;
    return p->cst ? p->vol : p->edecay;
}
static int mix_out(const Apu *a) {
    int tri = a->t.period < 2 ? 8 : tri_tab[a->t.seq];
    int nz = (a->n.len && !(a->n.lfsr & 1)) ? (a->n.cst ? a->n.vol : a->n.edecay) : 0;
    return pulse_mix[pulse_out(&a->p[0]) + pulse_out(&a->p[1])] + tnd_mix[3 * tri + 2 * nz + a->d_level];
}

static void fc_event(Apu *a) {
    int s = a->fc_step;
    if (!a->mode5) {
        clock_quarter(a); if (s == 1 || s == 3) clock_half(a);
        if (s == 3) { if (!a->irq_inhibit) a->frame_irq = 1; a->fc_step = 0; a->fc_cycle = 0; } else a->fc_step++;
    } else {
        if (s != 3) { clock_quarter(a); if (s == 1 || s == 4) clock_half(a); }
        if (s == 4) { a->fc_step = 0; a->fc_cycle = 0; } else a->fc_step++;
    }
}

void apu_run(Nes *n, int cycles) {
    Apu *a = &n->apu;
    while (cycles > 0) {
        int to_sub = (a->sub_cnt + 255) >> 8; if (to_sub < 1) to_sub = 1;
        int target = a->mode5 ? fc5[a->fc_step] : fc4[a->fc_step];
        int to_fc = target - a->fc_cycle; if (to_fc < 1) to_fc = 1;
        int chunk = cycles;
        if (to_sub < chunk) chunk = to_sub;
        if (to_fc < chunk) chunk = to_fc;
        advance(n, chunk);
        cycles -= chunk; a->fc_cycle += chunk; a->sub_cnt -= chunk << 8;
        if (a->fc_cycle >= target) fc_event(a);
        if (a->sub_cnt <= 0) {
            a->sub_cnt += SUB_STEP;
            a->acc += mix_out(a);
            if (++a->sub == OS) {
                int out = a->acc / OS; a->acc = 0; a->sub = 0;
                a->lp += ((out << 8) - a->lp) >> 8;
                out -= a->lp >> 8;
                if (out > 32767) out = 32767; else if (out < -32768) out = -32768;
                if (n->audio_n < AUDIO_CAP) n->audio[n->audio_n++] = (int16_t)out;
            }
        }
    }
}

void apu_write(Nes *n, uint16_t addr, uint8_t v) {
    Apu *a = &n->apu;
    if (addr <= 0x4007) {
        Pulse *p = &a->p[(addr >> 2) & 1];
        switch (addr & 3) {
        case 0: p->duty = v >> 6; p->halt = (v >> 5) & 1; p->cst = (v >> 4) & 1; p->vol = v & 15; break;
        case 1: p->swen = v >> 7; p->swper = (v >> 4) & 7; p->swneg = (v >> 3) & 1; p->swshift = v & 7; p->swreload = 1; break;
        case 2: p->period = (uint16_t)((p->period & 0x700) | v); break;
        case 3: p->period = (uint16_t)((p->period & 0xFF) | ((v & 7) << 8));
                if (p->en) p->len = len_tab[v >> 3];
                p->seq = 0; p->estart = 1; break;
        }
        return;
    }
    switch (addr) {
    case 0x4008: a->t.ctrl = v >> 7; a->t.linper = v & 0x7F; break;
    case 0x400A: a->t.period = (uint16_t)((a->t.period & 0x700) | v); break;
    case 0x400B: a->t.period = (uint16_t)((a->t.period & 0xFF) | ((v & 7) << 8));
                 if (a->t.en) a->t.len = len_tab[v >> 3];
                 a->t.linreload = 1; break;
    case 0x400C: a->n.halt = (v >> 5) & 1; a->n.cst = (v >> 4) & 1; a->n.vol = v & 15; break;
    case 0x400E: a->n.mode = v >> 7; a->n.period = noise_tab[v & 15]; break;
    case 0x400F: if (a->n.en) a->n.len = len_tab[v >> 3]; a->n.estart = 1; break;
    case 0x4010: a->d_irq_en = v >> 7; a->d_loop = (v >> 6) & 1; a->d_rate = dmc_tab[v & 15];
                 if (!a->d_irq_en) { a->dmc_irq = 0; } break;
    case 0x4011: a->d_level = v & 0x7F; break;
    case 0x4012: a->d_addr_start = (uint16_t)(0xC000 | (v << 6)); break;
    case 0x4013: a->d_len_start = (uint16_t)((v << 4) | 1); break;
    case 0x4015:
        a->p[0].en = v & 1; a->p[1].en = (v >> 1) & 1; a->t.en = (v >> 2) & 1; a->n.en = (v >> 3) & 1;
        if (!a->p[0].en) a->p[0].len = 0;
        if (!a->p[1].en) a->p[1].len = 0;
        if (!a->t.en) a->t.len = 0;
        if (!a->n.en) a->n.len = 0;
        a->dmc_irq = 0;
        if (v & 0x10) { if (a->d_bytes == 0) dmc_start(a); dmc_fetch(n); } else a->d_bytes = 0;
        break;
    case 0x4017:
        a->mode5 = v >> 7; a->irq_inhibit = (v >> 6) & 1;
        if (a->irq_inhibit) a->frame_irq = 0;
        a->fc_cycle = 0; a->fc_step = 0;
        if (a->mode5) { clock_quarter(a); clock_half(a); }
        break;
    default: break;
    }
}

uint8_t apu_read_status(Nes *n) {
    Apu *a = &n->apu;
    uint8_t v = (uint8_t)((a->p[0].len > 0) | ((a->p[1].len > 0) << 1) | ((a->t.len > 0) << 2) |
                          ((a->n.len > 0) << 3) | ((a->d_bytes > 0) << 4) | (a->frame_irq << 6) | (a->dmc_irq << 7));
    a->frame_irq = 0;
    return v;
}
