/* nes_ppu.c - scanline-based PPU.
 * Each visible line is rendered at line start using the current v/t registers; scroll
 * increments, mapper IRQ clocking and sprite-0 hit timing are applied at the right dots. */
#include "nes.h"
#include <string.h>

static uint32_t expand_tab[256];
static uint16_t rgb565_pal[64];

static const uint32_t nes_rgb[64] = {
 0x666666,0x002A88,0x1412A7,0x3B00A4,0x5C007E,0x6E0040,0x6C0600,0x561D00,
 0x333500,0x0B4800,0x005200,0x004F08,0x00404D,0x000000,0x000000,0x000000,
 0xADADAD,0x155FD9,0x4240FF,0x7527FE,0xA01ACC,0xB71E7B,0xB53120,0x994E00,
 0x6B6D00,0x388700,0x0C9300,0x008F32,0x007C8D,0x000000,0x000000,0x000000,
 0xFFFEFF,0x64B0FF,0x9290FF,0xC676FF,0xF36AFF,0xFE6ECC,0xFE8170,0xEA9E22,
 0xBCBE00,0x88D800,0x5CE430,0x45E082,0x48CDDE,0x4F4F4F,0x000000,0x000000,
 0xFFFEFF,0xC0DFFF,0xD3D2FF,0xE8C8FF,0xFBC2FF,0xFEC4EA,0xFECCC5,0xF7D8A5,
 0xE4E594,0xCFEF96,0xBDF4AB,0xB3F3CC,0xB5EBF2,0xB8B8B8,0x000000,0x000000
};

void ppu_init_tables(void) {
    for (int b = 0; b < 256; b++) {
        uint32_t v = 0;
        for (int i = 0; i < 8; i++) if (b & (0x80 >> i)) v |= 1u << (4 * i);
        expand_tab[b] = v;
    }
    for (int i = 0; i < 64; i++) {
        uint32_t r = (nes_rgb[i] >> 16) & 255, g = (nes_rgb[i] >> 8) & 255, b = nes_rgb[i] & 255;
        rgb565_pal[i] = (uint16_t)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
    }
}

void ppu_reset(Nes *n) {
    Ppu *p = &n->ppu;
    memset(p, 0, sizeof *p);
    p->s0_dot = -1;
}

static inline int pal_index(uint16_t a) { int i = a & 0x1F; return ((i & 0x13) == 0x10) ? (i & 0x0F) : i; }

static uint8_t ppu_rd(Nes *n, uint16_t a) {
    a &= 0x3FFF;
    if (a < 0x2000) return n->chr_map[a >> 10][a & 0x3FF];
    if (a < 0x3F00) return n->nt_map[(a >> 10) & 3][a & 0x3FF];
    return n->ppu.palette[pal_index(a)];
}
static void ppu_wr(Nes *n, uint16_t a, uint8_t v) {
    a &= 0x3FFF;
    if (a < 0x2000) { if (n->cart.chr_ram) n->chr_map[a >> 10][a & 0x3FF] = v; }
    else if (a < 0x3F00) n->nt_map[(a >> 10) & 3][a & 0x3FF] = v;
    else n->ppu.palette[pal_index(a)] = v & 0x3F;
}

uint8_t ppu_reg_read(Nes *n, int r) {
    Ppu *p = &n->ppu; uint8_t v;
    switch (r & 7) {
    case 2:
        if (p->s0_dot >= 0 && p->dot >= p->s0_dot) { p->status |= 0x40; p->s0_dot = -1; }
        v = (uint8_t)((p->status & 0xE0) | (p->latch & 0x1F));
        p->status &= ~0x80; p->w = 0;
        return v;
    case 4: v = p->oam[p->oam_addr]; break;
    case 7: {
        uint16_t a = p->v & 0x3FFF;
        if (a >= 0x3F00) { v = p->palette[pal_index(a)]; p->rbuf = ppu_rd(n, (uint16_t)(a - 0x1000)); }
        else { v = p->rbuf; p->rbuf = ppu_rd(n, a); }
        p->v = (uint16_t)(p->v + ((p->ctrl & 4) ? 32 : 1));
        break; }
    default: v = p->latch; break;
    }
    p->latch = v;
    return v;
}

void ppu_reg_write(Nes *n, int r, uint8_t v) {
    Ppu *p = &n->ppu;
    p->latch = v;
    switch (r & 7) {
    case 0:
        if (!(p->ctrl & 0x80) && (v & 0x80) && (p->status & 0x80)) n->cpu.nmi_pending = 1;
        p->ctrl = v; p->t = (uint16_t)((p->t & 0xF3FF) | ((v & 3) << 10));
        break;
    case 1: p->mask = v; break;
    case 3: p->oam_addr = v; break;
    case 4: p->oam[p->oam_addr++] = v; break;
    case 5:
        if (!p->w) { p->t = (uint16_t)((p->t & 0xFFE0) | (v >> 3)); p->fine_x = v & 7; }
        else p->t = (uint16_t)((p->t & 0x8C1F) | ((v & 7) << 12) | ((v & 0xF8) << 2));
        p->w ^= 1; break;
    case 6:
        if (!p->w) p->t = (uint16_t)((p->t & 0x00FF) | ((v & 0x3F) << 8));
        else { p->t = (uint16_t)((p->t & 0xFF00) | v); p->v = p->t; }
        p->w ^= 1; break;
    case 7:
        ppu_wr(n, p->v, v);
        p->v = (uint16_t)(p->v + ((p->ctrl & 4) ? 32 : 1));
        break;
    default: break;
    }
}

static void render_line(Nes *n, int y, int draw) {
    Ppu *p = &n->ppu;
    uint8_t bgbuf[264], spr[256];
    int sel[8], nsel = 0;
    int h = (p->ctrl & 0x20) ? 16 : 8;
    int bg_on = p->mask & 8, spr_on = p->mask & 0x10;

    if (!draw) {                       /* only needed if sprite 0 can hit on this line */
        int r0 = y - (p->oam[0] + 1);
        if (!spr_on || !bg_on || r0 < 0 || r0 >= h) return;
    }

    /* ---- background ---- */
    if (bg_on) {
        uint16_t v = p->v;
        int fy = (v >> 12) & 7, cx = v & 31, cy = (v >> 5) & 31, nt = (v >> 10) & 3;
        uint16_t pt = (p->ctrl & 0x10) ? 0x1000 : 0;
        for (int t = 0; t < 33; t++) {
            const uint8_t *ntp = n->nt_map[nt];
            uint8_t tile = ntp[(cy << 5) | cx];
            uint8_t at = ntp[0x3C0 + ((cy >> 2) << 3) + (cx >> 2)];
            int sh = ((cy & 2) << 1) | (cx & 2);
            uint32_t pal4 = (uint32_t)((at >> sh) & 3) << 2;
            uint16_t addr = (uint16_t)(pt + tile * 16 + fy);
            const uint8_t *pat = n->chr_map[addr >> 10] + (addr & 0x3FF);
            uint32_t px = expand_tab[pat[0]] | (expand_tab[pat[8]] << 1);
            px |= pal4 * 0x11111111u;
            uint8_t *o = bgbuf + t * 8;
            o[0] = px & 15; o[1] = (px >> 4) & 15; o[2] = (px >> 8) & 15; o[3] = (px >> 12) & 15;
            o[4] = (px >> 16) & 15; o[5] = (px >> 20) & 15; o[6] = (px >> 24) & 15; o[7] = px >> 28;
            if (++cx == 32) { cx = 0; nt ^= 1; }
        }
    } else memset(bgbuf, 0, sizeof bgbuf);
    uint8_t *bg = bgbuf + p->fine_x;
    if (!(p->mask & 2)) memset(bg, 0, 8);

    /* ---- sprites ---- */
    memset(spr, 0, sizeof spr);
    if (spr_on) {
        for (int i = 0; i < 64; i++) {
            int row = y - (p->oam[i * 4] + 1);
            if (row < 0 || row >= h) continue;
            if (nsel == 8) { p->status |= 0x20; break; }
            sel[nsel++] = i;
        }
        for (int k = nsel - 1; k >= 0; k--) {
            int i = sel[k];
            int row = y - (p->oam[i * 4] + 1);
            uint8_t tile = p->oam[i * 4 + 1], attr = p->oam[i * 4 + 2];
            int sx0 = p->oam[i * 4 + 3];
            if (attr & 0x80) row = h - 1 - row;
            uint16_t addr;
            if (h == 8) addr = (uint16_t)(((p->ctrl & 8) ? 0x1000 : 0) + tile * 16 + row);
            else addr = (uint16_t)(((tile & 1) << 12) + (tile & 0xFE) * 16 + (row & 7) + ((row & 8) ? 16 : 0));
            const uint8_t *pat = n->chr_map[addr >> 10] + (addr & 0x3FF);
            uint8_t lo = pat[0], hi = pat[8];
            uint8_t base = (uint8_t)(0x10 | ((attr & 3) << 2) | (attr & 0x20) | (i == 0 ? 0x40 : 0));
            for (int b = 0; b < 8; b++) {
                int sx = sx0 + b; if (sx > 255) break;
                int bit = (attr & 0x40) ? b : 7 - b;
                int pix = ((lo >> bit) & 1) | (((hi >> bit) & 1) << 1);
                if (pix) spr[sx] = (uint8_t)(base | pix);
            }
        }
        if (!(p->mask & 4)) memset(spr, 0, 8);
    }

    /* ---- composite ---- */
    uint16_t cpal[32];
    int gray = (p->mask & 1) ? 0x30 : 0x3F;
    for (int i = 0; i < 32; i++) cpal[i] = rgb565_pal[p->palette[(i & 3) ? i : 0] & gray];

    int hit = -1;
    uint16_t *col = n->frame + (239 - y);
    if (draw) {
        for (int x = 0; x < 256; x++) {
            uint8_t b = bg[x], s = spr[x]; uint16_t c;
            if (s & 0x10) {
                if (hit < 0 && (s & 0x40) && (b & 3) && x < 255) hit = x;
                c = ((b & 3) && (s & 0x20)) ? cpal[b] : cpal[16 + (s & 0x0F)];
            } else c = cpal[(b & 3) ? b : 0];
            col[x * 240] = c;
        }
    } else {
        for (int x = 0; x < 255; x++) if ((spr[x] & 0x50) == 0x50 && (bg[x] & 3)) { hit = x; break; }
    }
    if (hit >= 0 && !(p->status & 0x40)) p->s0_dot = (int16_t)(hit + 2);
}

void ppu_start_line(Nes *n) {
    Ppu *p = &n->ppu; int line = p->scanline;
    if (p->s0_dot >= 0) { p->status |= 0x40; p->s0_dot = -1; }
    if (line < 240) {
        if (p->mask & 0x18) render_line(n, line, !p->skip);
        else if (!p->skip) {
            uint16_t c = rgb565_pal[p->palette[0] & 0x3F];
            uint16_t *col = n->frame + (239 - line);
            for (int x = 0; x < 256; x++) col[x * 240] = c;
        }
    } else if (line == 241) {
        p->status |= 0x80;
        if (p->ctrl & 0x80) n->cpu.nmi_pending = 1;
    } else if (line == 261) {
        p->status &= (uint8_t)~0xE0; p->s0_dot = -1;
    }
}

/* called at dot 257: scroll increments + mapper scanline clock */
void ppu_hblank(Nes *n) {
    Ppu *p = &n->ppu; int line = p->scanline;
    if (!(p->mask & 0x18) || (line >= 240 && line != 261)) return;
    uint16_t v = p->v;
    if (line != 261) {
        if ((v & 0x7000) != 0x7000) v += 0x1000;
        else {
            v &= ~0x7000; int y = (v & 0x03E0) >> 5;
            if (y == 29) { y = 0; v ^= 0x0800; } else if (y == 31) y = 0; else y++;
            v = (uint16_t)((v & ~0x03E0) | (y << 5));
        }
    }
    v = (uint16_t)((v & ~0x041F) | (p->t & 0x041F));
    if (line == 261) v = (uint16_t)((v & ~0x7BE0) | (p->t & 0x7BE0));
    p->v = v;
    if (n->mapper && n->mapper->scanline) n->mapper->scanline(n);
}
