/* nes_cpu.c - MOS 6502 (2A03, no decimal mode). Official opcodes + common unofficial ones. */
#include "nes.h"

static const uint8_t cyc_tab[256] = {
 7,6,2,8,3,3,5,5,3,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
 6,6,2,8,3,3,5,5,4,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
 6,6,2,8,3,3,5,5,3,2,2,2,3,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
 6,6,2,8,3,3,5,5,4,2,2,2,5,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
 2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4, 2,6,2,6,4,4,4,4,2,5,2,5,5,5,5,5,
 2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4, 2,5,2,5,4,4,4,4,2,4,2,4,4,4,4,4,
 2,6,2,8,3,3,5,5,2,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
 2,6,2,8,3,3,5,5,2,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7
};

#define RD(a)    nes_read(n, (uint16_t)(a))
#define WR(a, v) nes_write(n, (uint16_t)(a), (v))

static inline uint16_t rd16(Nes *n, uint16_t a) { return (uint16_t)(RD(a) | (RD(a + 1) << 8)); }
static inline void push(Nes *n, uint8_t v) { n->ram[0x100 | n->cpu.sp--] = v; }
static inline uint8_t pull(Nes *n) { return n->ram[0x100 | ++n->cpu.sp]; }
static inline void push16(Nes *n, uint16_t v) { push(n, v >> 8); push(n, v & 0xFF); }
static inline uint16_t pull16(Nes *n) { uint16_t l = pull(n); return (uint16_t)(l | (pull(n) << 8)); }

static inline uint8_t get_p(const Cpu *c, int brk) {
    return (uint8_t)(c->c | (c->z << 1) | (c->i << 2) | (c->d << 3) | (brk ? 0x10 : 0) | 0x20 | (c->v << 6) | (c->n << 7));
}
static inline void set_p(Cpu *c, uint8_t p) {
    c->c = p & 1; c->z = (p >> 1) & 1; c->i = (p >> 2) & 1; c->d = (p >> 3) & 1;
    c->v = (p >> 6) & 1; c->n = p >> 7;
}
static inline void set_nz(Cpu *c, uint8_t v) { c->z = (v == 0); c->n = v >> 7; }

static inline void adc(Cpu *c, uint8_t m) {
    uint16_t s = c->a + m + c->c;
    c->v = ((~(c->a ^ m) & (c->a ^ s)) >> 7) & 1;
    c->c = s > 0xFF; c->a = (uint8_t)s; set_nz(c, c->a);
}
static inline void cmp(Cpu *c, uint8_t r, uint8_t m) { c->c = r >= m; set_nz(c, (uint8_t)(r - m)); }
static inline uint8_t op_asl(Cpu *c, uint8_t v) { c->c = v >> 7; v <<= 1; set_nz(c, v); return v; }
static inline uint8_t op_lsr(Cpu *c, uint8_t v) { c->c = v & 1; v >>= 1; set_nz(c, v); return v; }
static inline uint8_t op_rol(Cpu *c, uint8_t v) { uint8_t o = c->c; c->c = v >> 7; v = (uint8_t)((v << 1) | o); set_nz(c, v); return v; }
static inline uint8_t op_ror(Cpu *c, uint8_t v) { uint8_t o = c->c; c->c = v & 1; v = (uint8_t)((v >> 1) | (o << 7)); set_nz(c, v); return v; }

static void interrupt(Nes *n, uint16_t vec, int brk) {
    Cpu *c = &n->cpu;
    push16(n, c->pc); push(n, get_p(c, brk)); c->i = 1;
    c->pc = rd16(n, vec);
}

void cpu_reset(Nes *n) {
    Cpu *c = &n->cpu;
    c->a = c->x = c->y = 0; c->sp = 0xFD;
    set_p(c, 0x24); c->nmi_pending = 0; c->cycles = 0;
    c->pc = rd16(n, 0xFFFC);
}

/* effective-address helpers; 'cyc' collects page-cross penalties for read ops */
#define A_IMM   a = c->pc++
#define A_ZP    a = RD(c->pc++)
#define A_ZPX   a = (uint8_t)(RD(c->pc++) + c->x)
#define A_ZPY   a = (uint8_t)(RD(c->pc++) + c->y)
#define A_ABS   a = rd16(n, c->pc); c->pc += 2
#define A_IDX(reg, pen) { uint16_t b = rd16(n, c->pc); c->pc += 2; a = (uint16_t)(b + c->reg); if (pen) cyc += (((b ^ a) & 0xFF00) != 0); }
#define A_ABXR  A_IDX(x, 1)
#define A_ABXW  A_IDX(x, 0)
#define A_ABYR  A_IDX(y, 1)
#define A_ABYW  A_IDX(y, 0)
#define A_INDX  { uint8_t z = (uint8_t)(RD(c->pc++) + c->x); a = (uint16_t)(RD(z) | (RD((uint8_t)(z + 1)) << 8)); }
#define A_INDY(pen) { uint8_t z = RD(c->pc++); uint16_t b = (uint16_t)(RD(z) | (RD((uint8_t)(z + 1)) << 8)); a = (uint16_t)(b + c->y); if (pen) cyc += (((b ^ a) & 0xFF00) != 0); }
#define A_INDYR A_INDY(1)
#define A_INDYW A_INDY(0)

/* instruction bodies (operate on effective address 'a') */
#define I_LDA   c->a = RD(a); set_nz(c, c->a)
#define I_LDX   c->x = RD(a); set_nz(c, c->x)
#define I_LDY   c->y = RD(a); set_nz(c, c->y)
#define I_LAX   c->a = c->x = RD(a); set_nz(c, c->a)
#define I_STA   WR(a, c->a)
#define I_STX   WR(a, c->x)
#define I_STY   WR(a, c->y)
#define I_SAX   WR(a, c->a & c->x)
#define I_ORA   c->a |= RD(a); set_nz(c, c->a)
#define I_AND   c->a &= RD(a); set_nz(c, c->a)
#define I_EOR   c->a ^= RD(a); set_nz(c, c->a)
#define I_ADC   adc(c, RD(a))
#define I_SBC   adc(c, (uint8_t)(RD(a) ^ 0xFF))
#define I_CMP   cmp(c, c->a, RD(a))
#define I_CPX   cmp(c, c->x, RD(a))
#define I_CPY   cmp(c, c->y, RD(a))
#define I_BIT   m = RD(a); c->z = ((c->a & m) == 0); c->v = (m >> 6) & 1; c->n = m >> 7
#define RMW(fn) m = RD(a); WR(a, fn(c, m))
#define I_INC   m = (uint8_t)(RD(a) + 1); WR(a, m); set_nz(c, m)
#define I_DEC   m = (uint8_t)(RD(a) - 1); WR(a, m); set_nz(c, m)
#define I_SLO   m = op_asl(c, RD(a)); WR(a, m); c->a |= m; set_nz(c, c->a)
#define I_RLA   m = op_rol(c, RD(a)); WR(a, m); c->a &= m; set_nz(c, c->a)
#define I_SRE   m = op_lsr(c, RD(a)); WR(a, m); c->a ^= m; set_nz(c, c->a)
#define I_RRA   m = op_ror(c, RD(a)); WR(a, m); adc(c, m)
#define I_DCP   m = (uint8_t)(RD(a) - 1); WR(a, m); cmp(c, c->a, m)
#define I_ISB   m = (uint8_t)(RD(a) + 1); WR(a, m); adc(c, (uint8_t)(m ^ 0xFF))
#define BR(cond) { int8_t o = (int8_t)RD(c->pc++); if (cond) { uint16_t np = (uint16_t)(c->pc + o); cyc += 1 + (((c->pc ^ np) & 0xFF00) != 0); c->pc = np; } }

int cpu_step(Nes *n) {
    Cpu *c = &n->cpu;
    int cyc;
    uint16_t a; uint8_t m;

    if (c->nmi_pending) { c->nmi_pending = 0; interrupt(n, 0xFFFA, 0); c->cycles += 7; return 7; }
    if ((n->mapper_irq | n->apu.frame_irq | n->apu.dmc_irq) && !c->i) { interrupt(n, 0xFFFE, 0); c->cycles += 7; return 7; }

    uint8_t op = RD(c->pc++);
    cyc = cyc_tab[op];
    switch (op) {
    /* loads / stores */
    case 0xA9: A_IMM;  I_LDA; break; case 0xA5: A_ZP;   I_LDA; break; case 0xB5: A_ZPX;  I_LDA; break;
    case 0xAD: A_ABS;  I_LDA; break; case 0xBD: A_ABXR; I_LDA; break; case 0xB9: A_ABYR; I_LDA; break;
    case 0xA1: A_INDX; I_LDA; break; case 0xB1: A_INDYR; I_LDA; break;
    case 0xA2: A_IMM;  I_LDX; break; case 0xA6: A_ZP;   I_LDX; break; case 0xB6: A_ZPY;  I_LDX; break;
    case 0xAE: A_ABS;  I_LDX; break; case 0xBE: A_ABYR; I_LDX; break;
    case 0xA0: A_IMM;  I_LDY; break; case 0xA4: A_ZP;   I_LDY; break; case 0xB4: A_ZPX;  I_LDY; break;
    case 0xAC: A_ABS;  I_LDY; break; case 0xBC: A_ABXR; I_LDY; break;
    case 0x85: A_ZP;   I_STA; break; case 0x95: A_ZPX;  I_STA; break; case 0x8D: A_ABS;  I_STA; break;
    case 0x9D: A_ABXW; I_STA; break; case 0x99: A_ABYW; I_STA; break; case 0x81: A_INDX; I_STA; break;
    case 0x91: A_INDYW; I_STA; break;
    case 0x86: A_ZP;   I_STX; break; case 0x96: A_ZPY;  I_STX; break; case 0x8E: A_ABS;  I_STX; break;
    case 0x84: A_ZP;   I_STY; break; case 0x94: A_ZPX;  I_STY; break; case 0x8C: A_ABS;  I_STY; break;
    /* logic / arithmetic */
    case 0x09: A_IMM;  I_ORA; break; case 0x05: A_ZP;   I_ORA; break; case 0x15: A_ZPX;  I_ORA; break;
    case 0x0D: A_ABS;  I_ORA; break; case 0x1D: A_ABXR; I_ORA; break; case 0x19: A_ABYR; I_ORA; break;
    case 0x01: A_INDX; I_ORA; break; case 0x11: A_INDYR; I_ORA; break;
    case 0x29: A_IMM;  I_AND; break; case 0x25: A_ZP;   I_AND; break; case 0x35: A_ZPX;  I_AND; break;
    case 0x2D: A_ABS;  I_AND; break; case 0x3D: A_ABXR; I_AND; break; case 0x39: A_ABYR; I_AND; break;
    case 0x21: A_INDX; I_AND; break; case 0x31: A_INDYR; I_AND; break;
    case 0x49: A_IMM;  I_EOR; break; case 0x45: A_ZP;   I_EOR; break; case 0x55: A_ZPX;  I_EOR; break;
    case 0x4D: A_ABS;  I_EOR; break; case 0x5D: A_ABXR; I_EOR; break; case 0x59: A_ABYR; I_EOR; break;
    case 0x41: A_INDX; I_EOR; break; case 0x51: A_INDYR; I_EOR; break;
    case 0x69: A_IMM;  I_ADC; break; case 0x65: A_ZP;   I_ADC; break; case 0x75: A_ZPX;  I_ADC; break;
    case 0x6D: A_ABS;  I_ADC; break; case 0x7D: A_ABXR; I_ADC; break; case 0x79: A_ABYR; I_ADC; break;
    case 0x61: A_INDX; I_ADC; break; case 0x71: A_INDYR; I_ADC; break;
    case 0xE9: case 0xEB: A_IMM; I_SBC; break;
    case 0xE5: A_ZP;   I_SBC; break; case 0xF5: A_ZPX;  I_SBC; break;
    case 0xED: A_ABS;  I_SBC; break; case 0xFD: A_ABXR; I_SBC; break; case 0xF9: A_ABYR; I_SBC; break;
    case 0xE1: A_INDX; I_SBC; break; case 0xF1: A_INDYR; I_SBC; break;
    case 0xC9: A_IMM;  I_CMP; break; case 0xC5: A_ZP;   I_CMP; break; case 0xD5: A_ZPX;  I_CMP; break;
    case 0xCD: A_ABS;  I_CMP; break; case 0xDD: A_ABXR; I_CMP; break; case 0xD9: A_ABYR; I_CMP; break;
    case 0xC1: A_INDX; I_CMP; break; case 0xD1: A_INDYR; I_CMP; break;
    case 0xE0: A_IMM;  I_CPX; break; case 0xE4: A_ZP;   I_CPX; break; case 0xEC: A_ABS;  I_CPX; break;
    case 0xC0: A_IMM;  I_CPY; break; case 0xC4: A_ZP;   I_CPY; break; case 0xCC: A_ABS;  I_CPY; break;
    case 0x24: A_ZP;   I_BIT; break; case 0x2C: A_ABS;  I_BIT; break;
    /* shifts / inc / dec */
    case 0x0A: c->a = op_asl(c, c->a); break; case 0x4A: c->a = op_lsr(c, c->a); break;
    case 0x2A: c->a = op_rol(c, c->a); break; case 0x6A: c->a = op_ror(c, c->a); break;
    case 0x06: A_ZP;   RMW(op_asl); break; case 0x16: A_ZPX; RMW(op_asl); break;
    case 0x0E: A_ABS;  RMW(op_asl); break; case 0x1E: A_ABXW; RMW(op_asl); break;
    case 0x46: A_ZP;   RMW(op_lsr); break; case 0x56: A_ZPX; RMW(op_lsr); break;
    case 0x4E: A_ABS;  RMW(op_lsr); break; case 0x5E: A_ABXW; RMW(op_lsr); break;
    case 0x26: A_ZP;   RMW(op_rol); break; case 0x36: A_ZPX; RMW(op_rol); break;
    case 0x2E: A_ABS;  RMW(op_rol); break; case 0x3E: A_ABXW; RMW(op_rol); break;
    case 0x66: A_ZP;   RMW(op_ror); break; case 0x76: A_ZPX; RMW(op_ror); break;
    case 0x6E: A_ABS;  RMW(op_ror); break; case 0x7E: A_ABXW; RMW(op_ror); break;
    case 0xE6: A_ZP;   I_INC; break; case 0xF6: A_ZPX; I_INC; break; case 0xEE: A_ABS; I_INC; break; case 0xFE: A_ABXW; I_INC; break;
    case 0xC6: A_ZP;   I_DEC; break; case 0xD6: A_ZPX; I_DEC; break; case 0xCE: A_ABS; I_DEC; break; case 0xDE: A_ABXW; I_DEC; break;
    case 0xE8: c->x++; set_nz(c, c->x); break; case 0xC8: c->y++; set_nz(c, c->y); break;
    case 0xCA: c->x--; set_nz(c, c->x); break; case 0x88: c->y--; set_nz(c, c->y); break;
    /* transfers / flags / stack */
    case 0xAA: c->x = c->a; set_nz(c, c->x); break; case 0xA8: c->y = c->a; set_nz(c, c->y); break;
    case 0x8A: c->a = c->x; set_nz(c, c->a); break; case 0x98: c->a = c->y; set_nz(c, c->a); break;
    case 0xBA: c->x = c->sp; set_nz(c, c->x); break; case 0x9A: c->sp = c->x; break;
    case 0x18: c->c = 0; break; case 0x38: c->c = 1; break; case 0x58: c->i = 0; break; case 0x78: c->i = 1; break;
    case 0xB8: c->v = 0; break; case 0xD8: c->d = 0; break; case 0xF8: c->d = 1; break;
    case 0x48: push(n, c->a); break; case 0x08: push(n, get_p(c, 1)); break;
    case 0x68: c->a = pull(n); set_nz(c, c->a); break; case 0x28: set_p(c, pull(n)); break;
    /* branches */
    case 0x10: BR(!c->n); break; case 0x30: BR(c->n); break; case 0x50: BR(!c->v); break; case 0x70: BR(c->v); break;
    case 0x90: BR(!c->c); break; case 0xB0: BR(c->c); break; case 0xD0: BR(!c->z); break; case 0xF0: BR(c->z); break;
    /* jumps */
    case 0x4C: c->pc = rd16(n, c->pc); break;
    case 0x6C: { uint16_t p = rd16(n, c->pc); c->pc = (uint16_t)(RD(p) | (RD((p & 0xFF00) | ((p + 1) & 0xFF)) << 8)); } break;
    case 0x20: a = rd16(n, c->pc); c->pc++; push16(n, c->pc); c->pc = a; break;
    case 0x60: c->pc = (uint16_t)(pull16(n) + 1); break;
    case 0x40: set_p(c, pull(n)); c->pc = pull16(n); break;
    case 0x00: c->pc++; interrupt(n, 0xFFFE, 1); break;
    case 0xEA: break;
    /* unofficial NOPs */
    case 0x1A: case 0x3A: case 0x5A: case 0x7A: case 0xDA: case 0xFA: break;
    case 0x80: case 0x82: case 0x89: case 0xC2: case 0xE2: c->pc++; break;
    case 0x04: case 0x44: case 0x64: case 0x14: case 0x34: case 0x54: case 0x74: case 0xD4: case 0xF4: c->pc++; break;
    case 0x0C: c->pc += 2; break;
    case 0x1C: case 0x3C: case 0x5C: case 0x7C: case 0xDC: case 0xFC: A_ABXR; (void)a; break;
    /* unofficial combined ops */
    case 0xA7: A_ZP; I_LAX; break; case 0xB7: A_ZPY; I_LAX; break; case 0xAF: A_ABS; I_LAX; break;
    case 0xBF: A_ABYR; I_LAX; break; case 0xA3: A_INDX; I_LAX; break; case 0xB3: A_INDYR; I_LAX; break;
    case 0x87: A_ZP; I_SAX; break; case 0x97: A_ZPY; I_SAX; break; case 0x8F: A_ABS; I_SAX; break; case 0x83: A_INDX; I_SAX; break;
    case 0x07: A_ZP; I_SLO; break; case 0x17: A_ZPX; I_SLO; break; case 0x0F: A_ABS; I_SLO; break;
    case 0x1F: A_ABXW; I_SLO; break; case 0x1B: A_ABYW; I_SLO; break; case 0x03: A_INDX; I_SLO; break; case 0x13: A_INDYW; I_SLO; break;
    case 0x27: A_ZP; I_RLA; break; case 0x37: A_ZPX; I_RLA; break; case 0x2F: A_ABS; I_RLA; break;
    case 0x3F: A_ABXW; I_RLA; break; case 0x3B: A_ABYW; I_RLA; break; case 0x23: A_INDX; I_RLA; break; case 0x33: A_INDYW; I_RLA; break;
    case 0x47: A_ZP; I_SRE; break; case 0x57: A_ZPX; I_SRE; break; case 0x4F: A_ABS; I_SRE; break;
    case 0x5F: A_ABXW; I_SRE; break; case 0x5B: A_ABYW; I_SRE; break; case 0x43: A_INDX; I_SRE; break; case 0x53: A_INDYW; I_SRE; break;
    case 0x67: A_ZP; I_RRA; break; case 0x77: A_ZPX; I_RRA; break; case 0x6F: A_ABS; I_RRA; break;
    case 0x7F: A_ABXW; I_RRA; break; case 0x7B: A_ABYW; I_RRA; break; case 0x63: A_INDX; I_RRA; break; case 0x73: A_INDYW; I_RRA; break;
    case 0xC7: A_ZP; I_DCP; break; case 0xD7: A_ZPX; I_DCP; break; case 0xCF: A_ABS; I_DCP; break;
    case 0xDF: A_ABXW; I_DCP; break; case 0xDB: A_ABYW; I_DCP; break; case 0xC3: A_INDX; I_DCP; break; case 0xD3: A_INDYW; I_DCP; break;
    case 0xE7: A_ZP; I_ISB; break; case 0xF7: A_ZPX; I_ISB; break; case 0xEF: A_ABS; I_ISB; break;
    case 0xFF: A_ABXW; I_ISB; break; case 0xFB: A_ABYW; I_ISB; break; case 0xE3: A_INDX; I_ISB; break; case 0xF3: A_INDYW; I_ISB; break;
    default: break;   /* JAM / unstable opcodes: treated as 2-cycle NOP */
    }
    c->cycles += cyc;
    return cyc;
}
