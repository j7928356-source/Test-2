/* main.c - NES emulator for the (Old) Nintendo 3DS. Entry point + state machine. */
#include <3ds.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include "nes.h"
#include "nes_audio.h"
#include "nes_config.h"
#include "nes_input.h"
#include "nes_menu.h"
#include "nes_render.h"

#define TICKS_PER_FRAME (SYSCLOCK_ARM11 / 60)

static Nes g_nes;           /* ~130 KB, lives in .bss */
static Config g_cfg;

enum { S_MAIN, S_BROWSER, S_RECENT, S_SETTINGS, S_ABOUT, S_GAME, S_QUIT };
enum { G_BROWSER, G_EXIT };

static void game_screen(const char *path, bool paused_msg) {
    const char *b = strrchr(path, '/'); b = b ? b + 1 : path;
    consoleClear();
    printf("\x1b[1;1H\x1b[33;1m NES EMULATOR\x1b[0m\n ----------------------------------------\n\n");
    printf(" Game: %.32s\n Mapper: %s\n\n", b, g_nes.mapper ? g_nes.mapper->name : "?");
    printf(" START      pause menu\n X / Y       Select / Start\n D-Pad       move\n L / R       %s / %s\n",
           "turbo/aux", "turbo/aux");
    (void)paused_msg;
}

static int play(void) {
    char status[64] = "", spath[300];
    u64 skip = 0, skipped = 0, t_fps = svcGetSystemTick(); unsigned fnum = 0, fcount = 0;
    game_screen(g_nes.cart.path, false);
    for (;;) {
        if (!aptMainLoop()) return G_EXIT;
        hidScanInput();
        if (hidKeysDown() & KEY_START) {
            render_game(g_nes.frame, g_cfg.scale); render_game(g_nes.frame, g_cfg.scale);  /* both buffers */
            rom_save_sram(&g_nes);
            status[0] = 0;
            for (;;) {
                int a = menu_pause(status);
                ss_path(&g_nes, spath, sizeof spath);
                if (a == PAUSE_RESUME) break;
                if (a == PAUSE_SAVE) snprintf(status, sizeof status, ss_save(&g_nes, spath) ? "State saved." : "Save failed!");
                else if (a == PAUSE_LOAD) snprintf(status, sizeof status, ss_load(&g_nes, spath) ? "State loaded." : "No valid state found.");
                else if (a == PAUSE_RESET) { nes_reset(&g_nes); break; }
                else if (a == PAUSE_BROWSER) { rom_save_sram(&g_nes); return G_BROWSER; }
                else return G_EXIT;
            }
            game_screen(g_nes.cart.path, false);
            skip = skipped = 0; t_fps = svcGetSystemTick(); fcount = 0;
            continue;
        }
        g_nes.joy_buttons = input_poll(&g_cfg, fnum++);
        u64 t0 = svcGetSystemTick();
        g_nes.ppu.skip = (uint8_t)skip;
        nes_run_frame(&g_nes);
        if (!skip) render_game(g_nes.frame, g_cfg.scale);
        if (g_cfg.audio) audio_push(g_nes.audio, g_nes.audio_n);
        u64 dt = svcGetSystemTick() - t0;
        if (dt > TICKS_PER_FRAME) {            /* running behind: don't wait, maybe skip next draw */
            if (g_cfg.frameskip && skipped < 2) { skip = 1; skipped++; } else { skip = 0; skipped = 0; }
        } else { skip = 0; skipped = 0; gspWaitForVBlank(); }

        if (g_cfg.showfps && ++fcount == 60) {
            u64 now = svcGetSystemTick();
            printf("\x1b[12;1H FPS: %2u  ", (unsigned)((60ULL * SYSCLOCK_ARM11) / (now - t_fps)));
            t_fps = now; fcount = 0;
            gfxFlushBuffers();
        }
    }
}

static void make_dirs(void) {
    mkdir("sdmc:/roms", 0777); mkdir("sdmc:/roms/nes", 0777);
    mkdir("sdmc:/3ds", 0777); mkdir("sdmc:/3ds/nes3ds", 0777); mkdir("sdmc:/3ds/nes3ds/states", 0777);
}

static bool launch(const char *path) {
    const char *err = rom_load(&g_nes, path);
    if (err) { menu_message("Cannot load ROM", err); return false; }
    nes_reset(&g_nes);
    recent_add(&g_cfg, path); config_save(&g_cfg);
    return true;
}

int main(void) {
    bool isNew = false;
    if (R_SUCCEEDED(APT_CheckNew3DS(&isNew)) && isNew) osSetSpeedupEnable(true);  /* optional; Old 3DS needs nothing */
    render_init();
    consoleInit(GFX_BOTTOM, NULL);
    make_dirs();
    config_load(&g_cfg);
    nes_init();
    audio_init();                          /* returns false if DSP firmware is missing: runs silent */

    int st = S_MAIN;
    char path[300];
    while (st != S_QUIT && aptMainLoop()) {
        if (st != S_GAME) { render_logo(); render_logo(); }
        switch (st) {
        case S_MAIN: {
            int r = menu_main();
            st = r == MAIN_LOAD ? S_BROWSER : r == MAIN_RECENT ? S_RECENT : r == MAIN_SETTINGS ? S_SETTINGS :
                 r == MAIN_ABOUT ? S_ABOUT : S_QUIT;
            break; }
        case S_BROWSER: case S_RECENT: {
            int r = st == S_BROWSER ? menu_browser(path, sizeof path) : menu_recent(&g_cfg, path, sizeof path);
            if (r < 0) st = S_QUIT;
            else if (r == 0) st = S_MAIN;
            else if (launch(path)) st = S_GAME;
            break; }
        case S_SETTINGS: menu_settings(&g_cfg); st = S_MAIN; break;
        case S_ABOUT: menu_about(); st = S_MAIN; break;
        case S_GAME:
            st = (play() == G_BROWSER) ? S_BROWSER : S_QUIT;
            if (st == S_BROWSER) { consoleClear(); }
            break;
        }
    }

    rom_unload(&g_nes);        /* flushes battery SRAM */
    config_save(&g_cfg);
    audio_exit();
    render_exit();
    return 0;
}
