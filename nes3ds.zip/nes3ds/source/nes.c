/* nes.c - top-level: init, reset, frame loop (NTSC: 262 lines x 341 dots, 3 dots per CPU cycle) */
#include "nes.h"
#include <string.h>

void nes_init(void) { ppu_init_tables(); apu_init(); }

void nes_reset(Nes *n) {
    memset(n->ram, 0, sizeof n->ram); memset(n->vram, 0, sizeof n->vram);
    n->joy_buttons = n->joy_shift = n->joy_strobe = n->mapper_irq = 0;
    ppu_reset(n); apu_reset(n);
    if (n->mapper) n->mapper->reset(n);
    cpu_reset(n);
    n->apu_cyc = n->cpu.cycles; n->frame_count = 0; n->audio_n = 0;
    memset(n->frame, 0, sizeof n->frame);
}

static void run_to(Nes *n, int dot) {
    Ppu *p = &n->ppu;
    while (p->dot < dot) p->dot = (int16_t)(p->dot + cpu_step(n) * 3);
}

void nes_run_frame(Nes *n) {
    Ppu *p = &n->ppu;
    n->audio_n = 0;
    for (int line = 0; line < 262; line++) {
        p->scanline = (int16_t)line;
        ppu_start_line(n);
        run_to(n, 257);
        ppu_hblank(n);
        run_to(n, 341);
        p->dot = (int16_t)(p->dot - 341);
        apu_run(n, (int)(n->cpu.cycles - n->apu_cyc));
        n->apu_cyc = n->cpu.cycles;
    }
    n->frame_count++;
}
