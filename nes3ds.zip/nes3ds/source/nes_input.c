/* nes_input.c - 3DS buttons -> NES pad. D-Pad/Circle Pad, A, B, X=Select, Y=Start, L/R configurable. */
#include <3ds.h>
#include "nes_input.h"

static uint8_t apply(int map, unsigned frame) {
    switch (map) {
    case BTN_A: return 1;
    case BTN_B: return 2;
    case BTN_SELECT: return 4;
    case BTN_START: return 8;
    case BTN_TURBO_A: return (frame & 2) ? 1 : 0;
    case BTN_TURBO_B: return (frame & 2) ? 2 : 0;
    default: return 0;
    }
}

uint8_t input_poll(const Config *cfg, unsigned frame) {
    u32 h = hidKeysHeld();
    uint8_t r = 0;
    if (h & KEY_A) r |= 1;
    if (h & KEY_B) r |= 2;
    if (h & KEY_X) r |= 4;
    if (h & KEY_Y) r |= 8;
    if (h & (KEY_DUP | KEY_CPAD_UP)) r |= 16;
    if (h & (KEY_DDOWN | KEY_CPAD_DOWN)) r |= 32;
    if (h & (KEY_DLEFT | KEY_CPAD_LEFT)) r |= 64;
    if (h & (KEY_DRIGHT | KEY_CPAD_RIGHT)) r |= 128;
    if (h & KEY_L) r |= apply(cfg->lmap, frame);
    if (h & KEY_R) r |= apply(cfg->rmap, frame);
    if ((r & 0x30) == 0x30) r &= (uint8_t)~0x30;   /* no simultaneous Up+Down */
    if ((r & 0xC0) == 0xC0) r &= (uint8_t)~0xC0;   /* no simultaneous Left+Right */
    return r;
}
