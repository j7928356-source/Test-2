/* nes_audio.c - ndsp output. One NES frame of mono PCM is queued per video frame.
 * The channel rate is nudged to 32000 * (3DS refresh / NES refresh) so the queue neither
 * grows nor starves when emulation is locked to the 3DS vblank. */
#include <3ds.h>
#include <string.h>
#include "nes_audio.h"
#include "nes.h"

#define NBUF 4
#define NDSP_RATE (32000.0f * 59.8261f / 60.0988f)

static ndspWaveBuf wb[NBUF];
static int16_t *abuf;
static bool ready;

bool audio_init(void) {
    if (R_FAILED(ndspInit())) return false;
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    ndspChnReset(0);
    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, NDSP_RATE);
    ndspChnSetFormat(0, NDSP_FORMAT_MONO_PCM16);
    float mix[12] = {0}; mix[0] = 1.0f; mix[1] = 1.0f;
    ndspChnSetMix(0, mix);
    abuf = (int16_t *)linearAlloc(NBUF * AUDIO_CAP * sizeof(int16_t));
    if (!abuf) { ndspExit(); return false; }
    memset(abuf, 0, NBUF * AUDIO_CAP * sizeof(int16_t));
    memset(wb, 0, sizeof wb);
    for (int i = 0; i < NBUF; i++) wb[i].data_vaddr = abuf + i * AUDIO_CAP;
    ready = true;
    return true;
}

void audio_push(const int16_t *s, int n) {
    if (!ready || n <= 0) return;
    for (int i = 0; i < NBUF; i++) {
        if (wb[i].status == NDSP_WBUF_FREE || wb[i].status == NDSP_WBUF_DONE) {
            int16_t *d = abuf + i * AUDIO_CAP;
            if (n > AUDIO_CAP) n = AUDIO_CAP;
            memcpy(d, s, (size_t)n * sizeof(int16_t));
            wb[i].data_vaddr = d; wb[i].nsamples = n; wb[i].looping = false;
            DSP_FlushDataCache(d, (u32)n * sizeof(int16_t));
            ndspChnWaveBufAdd(0, &wb[i]);
            return;
        }
    }
    /* all buffers busy: drop this frame's audio rather than blocking video */
}

void audio_exit(void) {
    if (!ready) return;
    ndspChnReset(0); ndspExit(); linearFree(abuf); ready = false;
}
