/* nes_rom.c - iNES / NES 2.0 loader + battery SRAM persistence */
#include "nes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char errbuf[96];

static void sav_path(const char *rom, char *out, size_t cap) {
    snprintf(out, cap, "%s", rom);
    char *dot = strrchr(out, '.'), *sl = strrchr(out, '/');
    if (dot && (!sl || dot > sl)) *dot = 0;
    size_t l = strlen(out);
    if (l + 5 < cap) strcpy(out + l, ".sav");
}

void rom_unload(Nes *n) {
    if (n->cart.loaded) rom_save_sram(n);
    free(n->cart.prg); free(n->cart.chr);
    memset(&n->cart, 0, sizeof n->cart);
    n->mapper = 0;
}

void rom_save_sram(Nes *n) {
    if (!n->cart.loaded || !n->cart.battery) return;
    char p[300]; sav_path(n->cart.path, p, sizeof p);
    FILE *f = fopen(p, "wb");
    if (f) { fwrite(n->prg_ram, 1, sizeof n->prg_ram, f); fclose(f); }
}

const char *rom_load(Nes *n, const char *path) {
    uint8_t h[16];
    FILE *f = fopen(path, "rb");
    if (!f) return "Cannot open file";
    if (fread(h, 1, 16, f) != 16) { fclose(f); return "File too small"; }
    if (memcmp(h, "NES\x1A", 4)) { fclose(f); return "Not an iNES ROM (bad header)"; }

    int nes2 = (h[7] & 0x0C) == 0x08;
    int mapper = (h[6] >> 4) | (nes2 || !(h[12] | h[13] | h[14] | h[15]) ? (h[7] & 0xF0) : 0);
    uint32_t prg16 = h[4], chr8 = h[5];
    if (nes2) {
        mapper |= (h[8] & 0x0F) << 8;
        if ((h[9] & 0x0F) == 0x0F || (h[9] >> 4) == 0x0F) { fclose(f); return "NES 2.0 exponent sizes unsupported"; }
        prg16 |= (uint32_t)(h[9] & 0x0F) << 8; chr8 |= (uint32_t)(h[9] >> 4) << 8;
    }
    const Mapper *mp = mapper_find(mapper);
    if (!mp) { fclose(f); snprintf(errbuf, sizeof errbuf, "Unsupported mapper %d", mapper); return errbuf; }
    if (prg16 == 0) { fclose(f); return "ROM has no PRG data"; }
    if (h[6] & 4) fseek(f, 512, SEEK_CUR);

    rom_unload(n);
    Cart *c = &n->cart;
    c->prg_size = prg16 * 16384u; c->prg_banks8 = prg16 * 2;
    c->prg = (uint8_t *)malloc(c->prg_size);
    if (chr8) { c->chr_size = chr8 * 8192u; c->chr = (uint8_t *)malloc(c->chr_size); }
    else { c->chr_size = 8192; c->chr = (uint8_t *)calloc(1, 8192); c->chr_ram = 1; }
    c->chr_banks1 = c->chr_size / 1024;
    if (!c->prg || !c->chr) { fclose(f); free(c->prg); free(c->chr); memset(c, 0, sizeof *c); return "Out of memory"; }
    if (fread(c->prg, 1, c->prg_size, f) != c->prg_size ||
        (!c->chr_ram && fread(c->chr, 1, c->chr_size, f) != c->chr_size)) {
        fclose(f); free(c->prg); free(c->chr); memset(c, 0, sizeof *c); return "ROM file is truncated";
    }
    fclose(f);

    c->mapper_id = (uint8_t)mapper;
    c->battery = (h[6] >> 1) & 1;
    c->mirroring = (h[6] & 8) ? MIR_4 : ((h[6] & 1) ? MIR_V : MIR_H);
    snprintf(c->path, sizeof c->path, "%s", path);
    c->loaded = true;
    n->mapper = mp;

    memset(n->prg_ram, 0, sizeof n->prg_ram);
    if (c->battery) {
        char p[300]; sav_path(path, p, sizeof p);
        FILE *s = fopen(p, "rb");
        if (s) { size_t r = fread(n->prg_ram, 1, sizeof n->prg_ram, s); (void)r; fclose(s); }
    }
    return NULL;
}
