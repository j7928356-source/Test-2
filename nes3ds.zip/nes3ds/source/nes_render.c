/* nes_render.c - top-screen output. The PPU already writes the frame in the 3DS's native
 * column-major RGB565 layout, so 1:1 display is a single memcpy of 120 KB. */
#include <3ds.h>
#include <string.h>
#include "nes_render.h"
#include "nes_config.h"

#define RGB(r, g, b) ((uint16_t)((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3)))

void render_init(void) {
    gfxInit(GSP_RGB565_OES, GSP_RGB565_OES, false);
    gfxSet3D(false);
}
void render_exit(void) { gfxExit(); }

void render_game(const uint16_t *frame, int scale) {
    static const int widths[SCALE_COUNT] = {256, 292, 400};
    u16 w, h;
    u16 *fb = (u16 *)gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &w, &h);   /* 240 x 400, column-major */
    int W = widths[scale < SCALE_COUNT ? scale : 0], off = (400 - W) / 2;
    if (off > 0) {
        memset(fb, 0, (size_t)off * 240 * 2);
        memset(fb + (size_t)(off + W) * 240, 0, (size_t)(400 - off - W) * 240 * 2);
    }
    u16 *dst = fb + (size_t)off * 240;
    if (W == 256) memcpy(dst, frame, 256 * 240 * 2);
    else for (int dx = 0; dx < W; dx++) memcpy(dst + dx * 240, frame + (dx * 256 / W) * 240, 240 * 2);
    gfxFlushBuffers();
    gfxSwapBuffers();
}

/* ---- tiny 5x5 block font for the title logo ---- */
static const struct { char c; uint8_t r[5]; } font[] = {
    {'N', {0x11,0x19,0x15,0x13,0x11}}, {'E', {0x1F,0x10,0x1E,0x10,0x1F}}, {'S', {0x0F,0x10,0x0E,0x01,0x1E}},
    {'M', {0x11,0x1B,0x15,0x11,0x11}}, {'U', {0x11,0x11,0x11,0x11,0x0E}}, {'L', {0x10,0x10,0x10,0x10,0x1F}},
    {'A', {0x0E,0x11,0x1F,0x11,0x11}}, {'T', {0x1F,0x04,0x04,0x04,0x04}}, {'O', {0x0E,0x11,0x11,0x11,0x0E}},
    {'R', {0x1E,0x11,0x1E,0x12,0x11}},
};
static void rect(u16 *fb, int x, int y, int w, int h, u16 c) {
    for (int xx = x; xx < x + w && xx < 400; xx++)
        for (int yy = y; yy < y + h && yy < 240; yy++) fb[xx * 240 + (239 - yy)] = c;
}
static int text_w(const char *s, int sc) { int n = (int)strlen(s); return n * 5 * sc + (n - 1) * sc; }
static void text(u16 *fb, int x, int y, int sc, const char *s, u16 col, u16 shadow) {
    for (; *s; s++, x += 6 * sc)
        for (unsigned i = 0; i < sizeof font / sizeof font[0]; i++) if (font[i].c == *s)
            for (int r = 0; r < 5; r++) for (int b = 0; b < 5; b++) if (font[i].r[r] & (0x10 >> b)) {
                rect(fb, x + b * sc + sc / 2, y + r * sc + sc / 2, sc, sc, shadow);
                rect(fb, x + b * sc, y + r * sc, sc, sc, col);
            }
}

void render_logo(void) {
    u16 w, h;
    u16 *fb = (u16 *)gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &w, &h);
    rect(fb, 0, 0, 400, 240, RGB(16, 16, 28));
    text(fb, (400 - text_w("NES", 14)) / 2, 34, 14, "NES", RGB(230, 50, 50), RGB(90, 10, 10));
    text(fb, (400 - text_w("EMULATOR", 6)) / 2, 128, 6, "EMULATOR", RGB(220, 220, 220), RGB(60, 60, 70));
    static const u16 stripe[4] = {RGB(230, 50, 50), RGB(240, 150, 30), RGB(240, 220, 60), RGB(60, 190, 90)};
    for (int i = 0; i < 4; i++) rect(fb, 60, 184 + i * 7, 280, 5, stripe[i]);
    gfxFlushBuffers();
    gfxSwapBuffers();
}
