/* nes_mapper.c - bank-mapping helpers + mappers 0,1,2,3,4,7.
 * To add a mapper: write reset/write/sync(/scanline) functions, add a row to mappers[]. */
#include "nes.h"
#include <string.h>

void nes_set_mirroring(Nes *n, int m) {
    static const uint8_t tab[5][4] = {{0,0,1,1},{0,1,0,1},{0,0,0,0},{1,1,1,1},{0,1,2,3}};
    for (int i = 0; i < 4; i++) n->nt_map[i] = n->vram + tab[m][i] * 1024;
}
void nes_map_prg8(Nes *n, int slot, int bank) { n->prg_map[slot] = n->cart.prg + ((uint32_t)bank % n->cart.prg_banks8) * 8192u; }
void nes_map_prg16(Nes *n, int s, int b) { nes_map_prg8(n, s * 2, b * 2); nes_map_prg8(n, s * 2 + 1, b * 2 + 1); }
void nes_map_prg32(Nes *n, int b) { for (int i = 0; i < 4; i++) nes_map_prg8(n, i, b * 4 + i); }
void nes_map_chr1(Nes *n, int slot, int bank) { n->chr_map[slot] = n->cart.chr + ((uint32_t)bank % n->cart.chr_banks1) * 1024u; }
void nes_map_chr2(Nes *n, int slot, int b) { nes_map_chr1(n, slot, b * 2); nes_map_chr1(n, slot + 1, b * 2 + 1); }
void nes_map_chr4(Nes *n, int slot, int b) { for (int i = 0; i < 4; i++) nes_map_chr1(n, slot + i, b * 4 + i); }
void nes_map_chr8(Nes *n, int b) { for (int i = 0; i < 8; i++) nes_map_chr1(n, i, b * 8 + i); }

static int last8(Nes *n) { return (int)n->cart.prg_banks8 - 1; }

/* ---- 0: NROM ---- */
static void nrom_sync(Nes *n) { nes_map_prg32(n, 0); nes_map_chr8(n, 0); nes_set_mirroring(n, n->cart.mirroring); }
static void nrom_reset(Nes *n) { nrom_sync(n); }
static void nrom_write(Nes *n, uint16_t a, uint8_t v) { (void)n; (void)a; (void)v; }

/* ---- 1: MMC1 (r[0]=ctrl r[1]=chr0 r[2]=chr1 r[3]=prg) ---- */
static void mmc1_sync(Nes *n) {
    MapperRegs *m = &n->mr; uint8_t ctrl = m->r[0];
    static const uint8_t mir[4] = {MIR_S0, MIR_S1, MIR_V, MIR_H};
    nes_set_mirroring(n, mir[ctrl & 3]);
    int pm = (ctrl >> 2) & 3, prg = m->r[3] & 15;
    if (pm < 2) nes_map_prg32(n, prg >> 1);
    else if (pm == 2) { nes_map_prg16(n, 0, 0); nes_map_prg16(n, 1, prg); }
    else { nes_map_prg16(n, 0, prg); nes_map_prg16(n, 1, last8(n) / 2); }
    if (ctrl & 0x10) { nes_map_chr4(n, 0, m->r[1]); nes_map_chr4(n, 4, m->r[2]); }
    else nes_map_chr8(n, m->r[1] >> 1);
}
static void mmc1_reset(Nes *n) { memset(&n->mr, 0, sizeof n->mr); n->mr.r[0] = 0x0C; mmc1_sync(n); }
static void mmc1_write(Nes *n, uint16_t a, uint8_t v) {
    MapperRegs *m = &n->mr;
    if (v & 0x80) { m->sr = 0; m->sr_cnt = 0; m->r[0] |= 0x0C; mmc1_sync(n); return; }
    m->sr = (uint8_t)((m->sr >> 1) | ((v & 1) << 4));
    if (++m->sr_cnt == 5) { m->r[(a >> 13) & 3] = m->sr; m->sr = 0; m->sr_cnt = 0; mmc1_sync(n); }
}

/* ---- 2: UxROM ---- */
static void uxrom_sync(Nes *n) {
    nes_map_prg16(n, 0, n->mr.r[0]); nes_map_prg16(n, 1, last8(n) / 2);
    nes_map_chr8(n, 0); nes_set_mirroring(n, n->cart.mirroring);
}
static void uxrom_reset(Nes *n) { memset(&n->mr, 0, sizeof n->mr); uxrom_sync(n); }
static void uxrom_write(Nes *n, uint16_t a, uint8_t v) { (void)a; n->mr.r[0] = v; uxrom_sync(n); }

/* ---- 3: CNROM ---- */
static void cnrom_sync(Nes *n) { nes_map_prg32(n, 0); nes_map_chr8(n, n->mr.r[0]); nes_set_mirroring(n, n->cart.mirroring); }
static void cnrom_reset(Nes *n) { memset(&n->mr, 0, sizeof n->mr); cnrom_sync(n); }
static void cnrom_write(Nes *n, uint16_t a, uint8_t v) { (void)a; n->mr.r[0] = v; cnrom_sync(n); }

/* ---- 4: MMC3 (r[0]=bank select, bank[0..7], latch/counter/reload/irq_en, mirror) ---- */
static void mmc3_sync(Nes *n) {
    MapperRegs *m = &n->mr; int inv = (m->r[0] & 0x80) ? 4 : 0, pm = m->r[0] & 0x40;
    nes_map_chr2(n, 0 ^ inv, m->bank[0] >> 1);
    nes_map_chr2(n, 2 ^ inv, m->bank[1] >> 1);
    for (int i = 0; i < 4; i++) nes_map_chr1(n, (4 ^ inv) + i, m->bank[2 + i]);
    nes_map_prg8(n, pm ? 2 : 0, m->bank[6]);
    nes_map_prg8(n, 1, m->bank[7]);
    nes_map_prg8(n, pm ? 0 : 2, last8(n) - 1);
    nes_map_prg8(n, 3, last8(n));
    if (n->cart.mirroring != MIR_4) nes_set_mirroring(n, m->mirror ? MIR_H : MIR_V);
    else nes_set_mirroring(n, MIR_4);
}
static void mmc3_reset(Nes *n) {
    memset(&n->mr, 0, sizeof n->mr);
    n->mr.bank[0] = 0; n->mr.bank[1] = 2; n->mr.bank[2] = 4; n->mr.bank[3] = 5; n->mr.bank[4] = 6; n->mr.bank[5] = 7;
    n->mr.bank[6] = 0; n->mr.bank[7] = 1; n->mr.mirror = (n->cart.mirroring == MIR_H);
    mmc3_sync(n);
}
static void mmc3_write(Nes *n, uint16_t a, uint8_t v) {
    MapperRegs *m = &n->mr;
    switch (a & 0xE001) {
    case 0x8000: m->r[0] = v; mmc3_sync(n); break;
    case 0x8001: m->bank[m->r[0] & 7] = v; mmc3_sync(n); break;
    case 0xA000: m->mirror = v & 1; mmc3_sync(n); break;
    case 0xA001: break;
    case 0xC000: m->latch = v; break;
    case 0xC001: m->counter = 0; m->reload = 1; break;
    case 0xE000: m->irq_en = 0; n->mapper_irq = 0; break;
    case 0xE001: m->irq_en = 1; break;
    }
}
static void mmc3_scanline(Nes *n) {
    MapperRegs *m = &n->mr;
    if (m->counter == 0 || m->reload) { m->counter = m->latch; m->reload = 0; } else m->counter--;
    if (m->counter == 0 && m->irq_en) n->mapper_irq = 1;
}

/* ---- 7: AxROM ---- */
static void axrom_sync(Nes *n) {
    nes_map_prg32(n, n->mr.r[0] & 7); nes_map_chr8(n, 0);
    nes_set_mirroring(n, (n->mr.r[0] & 0x10) ? MIR_S1 : MIR_S0);
}
static void axrom_reset(Nes *n) { memset(&n->mr, 0, sizeof n->mr); axrom_sync(n); }
static void axrom_write(Nes *n, uint16_t a, uint8_t v) { (void)a; n->mr.r[0] = v; axrom_sync(n); }

static const Mapper mappers[] = {
    {0, "NROM",  nrom_reset,   nrom_write,   nrom_sync,   0},
    {1, "MMC1",  mmc1_reset,   mmc1_write,   mmc1_sync,   0},
    {2, "UxROM", uxrom_reset,  uxrom_write,  uxrom_sync,  0},
    {3, "CNROM", cnrom_reset,  cnrom_write,  cnrom_sync,  0},
    {4, "MMC3",  mmc3_reset,   mmc3_write,   mmc3_sync,   mmc3_scanline},
    {7, "AxROM", axrom_reset,  axrom_write,  axrom_sync,  0},
};

const Mapper *mapper_find(int id) {
    for (size_t i = 0; i < sizeof mappers / sizeof mappers[0]; i++) if (mappers[i].id == id) return &mappers[i];
    return 0;
}
