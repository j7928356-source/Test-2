/* nes_savestate.c - single-slot save states: sdmc:/3ds/nes3ds/states/<rom>.st0 */
#include "nes.h"
#include <stdio.h>
#include <string.h>

typedef struct { char magic[4]; uint32_t ver, mapper, prg_size; } SsHeader;
#define SS_VER 1

void ss_path(const Nes *n, char *out, size_t cap) {
    const char *b = strrchr(n->cart.path, '/'); b = b ? b + 1 : n->cart.path;
    char name[256]; snprintf(name, sizeof name, "%s", b);
    char *dot = strrchr(name, '.'); if (dot) *dot = 0;
    snprintf(out, cap, "sdmc:/3ds/nes3ds/states/%s.st0", name);
}

static size_t state_bytes(const Nes *n) {
    return sizeof(SsHeader) + sizeof(Cpu) + sizeof(Ppu) + sizeof(Apu) + sizeof(MapperRegs) +
           sizeof n->ram + sizeof n->vram + sizeof n->prg_ram + 4 + (n->cart.chr_ram ? n->cart.chr_size : 0);
}

bool ss_save(Nes *n, const char *path) {
    FILE *f = fopen(path, "wb"); if (!f) return false;
    SsHeader h = {{'N','3','S','S'}, SS_VER, n->cart.mapper_id, n->cart.prg_size};
    uint8_t j[4] = {n->joy_buttons, n->joy_shift, n->joy_strobe, n->mapper_irq};
    int ok = fwrite(&h, sizeof h, 1, f) == 1 && fwrite(&n->cpu, sizeof(Cpu), 1, f) == 1 &&
             fwrite(&n->ppu, sizeof(Ppu), 1, f) == 1 && fwrite(&n->apu, sizeof(Apu), 1, f) == 1 &&
             fwrite(&n->mr, sizeof(MapperRegs), 1, f) == 1 && fwrite(n->ram, sizeof n->ram, 1, f) == 1 &&
             fwrite(n->vram, sizeof n->vram, 1, f) == 1 && fwrite(n->prg_ram, sizeof n->prg_ram, 1, f) == 1 &&
             fwrite(j, 4, 1, f) == 1 && (!n->cart.chr_ram || fwrite(n->cart.chr, n->cart.chr_size, 1, f) == 1);
    fclose(f);
    return ok;
}

bool ss_load(Nes *n, const char *path) {
    FILE *f = fopen(path, "rb"); if (!f) return false;
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    SsHeader h;
    if (sz != (long)state_bytes(n) || fread(&h, sizeof h, 1, f) != 1 || memcmp(h.magic, "N3SS", 4) ||
        h.ver != SS_VER || h.mapper != n->cart.mapper_id || h.prg_size != n->cart.prg_size) { fclose(f); return false; }
    uint8_t j[4];
    int ok = fread(&n->cpu, sizeof(Cpu), 1, f) == 1 && fread(&n->ppu, sizeof(Ppu), 1, f) == 1 &&
             fread(&n->apu, sizeof(Apu), 1, f) == 1 && fread(&n->mr, sizeof(MapperRegs), 1, f) == 1 &&
             fread(n->ram, sizeof n->ram, 1, f) == 1 && fread(n->vram, sizeof n->vram, 1, f) == 1 &&
             fread(n->prg_ram, sizeof n->prg_ram, 1, f) == 1 && fread(j, 4, 1, f) == 1 &&
             (!n->cart.chr_ram || fread(n->cart.chr, n->cart.chr_size, 1, f) == 1);
    fclose(f);
    if (!ok) { nes_reset(n); return false; }
    n->joy_buttons = j[0]; n->joy_shift = j[1]; n->joy_strobe = j[2]; n->mapper_irq = j[3];
    n->mapper->sync(n);
    n->apu_cyc = n->cpu.cycles; n->audio_n = 0;
    return true;
}
