#include "nes.h"
#include <stdio.h>
#include <stdlib.h>
int main(void) {
    static Nes nes; Nes *n = &nes;
    nes_init();
    const char *e = rom_load(n, "/tmp/test.nes");
    if (e) { printf("load error: %s\n", e); return 1; }
    nes_reset(n);
    int audio = 0;
    for (int f = 0; f < 30; f++) { nes_run_frame(n); audio += n->audio_n; }
    printf("A0 test  ram[0]=%02X (exp A0)\n", n->ram[0]);
    printf("flags    ram[1]=%02X (exp F4)\n", n->ram[1]);
    printf("dex loop ram[2]=%02X (exp 00)\n", n->ram[2]);
    printf("jsr      ram[3]=%02X (exp 42)\n", n->ram[3]);
    printf("nmi cnt  ram[16]=%d (exp ~29-30)\n", n->ram[0x10]);
    printf("pixel(0,0)=%04X (exp tile color pal1 idx1=$30 -> white-ish) pixel(100,100)=%04X (backdrop $21)\n",
           n->frame[0 * 240 + 239], n->frame[100 * 240 + (239 - 100)]);
    printf("audio samples over 30 frames: %d (exp ~%d)\n", audio, 30 * 32000 * 1000 / 60099 / 1);
    /* save state round trip */
    ss_save(n, "/tmp/t.st0");
    uint8_t before = n->ram[0x10];
    for (int f = 0; f < 5; f++) nes_run_frame(n);
    printf("ss_load ok=%d ", ss_load(n, "/tmp/t.st0"));
    printf("ram[16] restored=%d (was %d)\n", n->ram[0x10], before);
    rom_unload(n);
    return 0;
}
