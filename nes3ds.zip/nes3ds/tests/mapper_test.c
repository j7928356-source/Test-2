#include "nes.h"
#include <stdio.h>
int main(void){
  static Nes nes; Nes *n=&nes; nes_init();
  int ids[]={0,1,2,3,4,7};
  for(int i=0;i<6;i++){
    char p[32]; snprintf(p,sizeof p,"/tmp/m%d.nes",ids[i]);
    const char*e=rom_load(n,p); if(e){printf("m%d load err %s\n",ids[i],e);continue;}
    nes_reset(n);
    for(int f=0;f<20;f++) nes_run_frame(n);
    printf("mapper %d (%s): ram0=%02X nmi=%d pix=%04X\n",ids[i],n->mapper->name,n->ram[0],n->ram[0x10],n->frame[239]);
    /* poke mapper registers to exercise bank switching */
    for(int w=0;w<16;w++) nes_write(n,0x8000+(w*0x2001&0x7FFF),(uint8_t)(w*7));
    for(int f=0;f<2;f++) nes_run_frame(n);
    rom_unload(n);
  }
  const char*e=rom_load(n,"/tmp/test.nes"); (void)e;
  FILE*f=fopen("/tmp/bad.nes","wb"); fwrite("garbage garbage garbage",1,23,f); fclose(f);
  printf("bad rom -> %s\n", rom_load(n,"/tmp/bad.nes"));
  uint8_t h[16]={0x4E,0x45,0x53,0x1A,1,1,0x50,0}; f=fopen("/tmp/m5.nes","wb"); fwrite(h,1,16,f); fclose(f);
  printf("mapper 5 -> %s\n", rom_load(n,"/tmp/m5.nes"));
  return 0;
}
