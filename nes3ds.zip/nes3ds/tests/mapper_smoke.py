import subprocess, struct
base = open('/tmp/test.nes','rb').read()
prg = base[16:16+0x4000]; chr_ = base[16+0x4000:]
for m, banks, chrb in [(1,8,2),(2,8,0),(3,2,4),(4,16,16),(7,8,0),(0,2,1)]:
    hdr = bytes([0x4E,0x45,0x53,0x1A,banks,chrb,(m&15)<<4,m&0xF0]+[0]*8)
    open('/tmp/m%d.nes'%m,'wb').write(hdr+prg*banks+chr_*(chrb))
