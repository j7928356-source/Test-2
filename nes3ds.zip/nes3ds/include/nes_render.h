#ifndef NES_RENDER_H
#define NES_RENDER_H
#include <stdint.h>
void render_init(void);
void render_exit(void);
/* frame: column-major RGB565 256x240 as produced by the PPU */
void render_game(const uint16_t *frame, int scale);
void render_logo(void);
#endif
