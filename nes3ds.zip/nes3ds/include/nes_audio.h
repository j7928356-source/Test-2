#ifndef NES_AUDIO_H
#define NES_AUDIO_H
#include <stdbool.h>
#include <stdint.h>
bool audio_init(void);                          /* false if DSP firmware missing: emulator runs silent */
void audio_push(const int16_t *s, int n);       /* mono 16-bit; one NES frame per call */
void audio_exit(void);
#endif
