#ifndef NES_INPUT_H
#define NES_INPUT_H
#include <stdint.h>
#include "nes_config.h"
/* Returns NES button bitmask (A=1 B=2 Sel=4 Start=8 Up=16 Down=32 Left=64 Right=128). Call after hidScanInput(). */
uint8_t input_poll(const Config *cfg, unsigned frame);
#endif
