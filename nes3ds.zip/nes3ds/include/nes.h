/* nes.h - core emulator types (platform independent, plain C99) */
#ifndef NES_CORE_H
#define NES_CORE_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#define NES_SCREEN_W 256
#define NES_SCREEN_H 240
#define CPU_HZ       1789773
#define AUDIO_RATE   32000
#define AUDIO_CAP    1024      /* max mono samples generated per NES frame */

enum { MIR_H = 0, MIR_V = 1, MIR_S0 = 2, MIR_S1 = 3, MIR_4 = 4 };

typedef struct Nes Nes;

/* ---- saved state structs: NO pointers allowed in these ---- */
typedef struct {
    uint16_t pc;
    uint8_t a, x, y, sp;
    uint8_t c, z, i, d, v, n;
    uint8_t nmi_pending;
    uint32_t cycles;
} Cpu;

typedef struct {
    uint8_t ctrl, mask, status, oam_addr, latch, w, fine_x, rbuf;
    uint16_t v, t;
    int16_t scanline, dot, s0_dot;
    uint8_t skip;                 /* runtime: skip pixel output this frame */
    uint8_t oam[256];
    uint8_t palette[32];
} Ppu;

typedef struct {
    uint8_t duty, seq, len, halt, cst, vol, estart, ediv, edecay;
    uint8_t swen, swper, swneg, swshift, swreload, swdiv, ch, en;
    uint16_t period; int32_t cnt;
} Pulse;
typedef struct {
    uint8_t ctrl, linreload, lin, linper, len, seq, en;
    uint16_t period; int32_t cnt;
} Tri;
typedef struct {
    uint8_t halt, cst, vol, estart, ediv, edecay, len, mode, en;
    uint16_t lfsr, period; int32_t cnt;
} Noise;
typedef struct {
    Pulse p[2]; Tri t; Noise n;
    /* DMC */
    uint8_t d_irq_en, d_loop, d_level, d_shift, d_bits, d_silence, d_buf, d_empty;
    uint16_t d_rate, d_addr_start, d_len_start, d_addr, d_bytes;
    int32_t d_cnt;
    /* frame counter / irq */
    uint8_t mode5, irq_inhibit, frame_irq, dmc_irq, fc_step;
    int32_t fc_cycle;
    /* sampler */
    int32_t sub_cnt, acc, lp; uint8_t sub;
} Apu;

typedef struct {
    uint8_t r[8], bank[8];
    uint8_t sr, sr_cnt, latch, counter, reload, irq_en, mirror, pad;
} MapperRegs;

typedef struct {
    uint8_t *prg; uint32_t prg_size, prg_banks8;
    uint8_t *chr; uint32_t chr_size, chr_banks1;
    uint8_t chr_ram, battery, mirroring, mapper_id;
    char path[256];
    bool loaded;
} Cart;

typedef struct Mapper {
    int id; const char *name;
    void (*reset)(Nes *);
    void (*write)(Nes *, uint16_t addr, uint8_t v);   /* $8000-$FFFF */
    void (*sync)(Nes *);                              /* re-apply banks from regs */
    void (*scanline)(Nes *);                          /* optional, once per rendered line */
} Mapper;

struct Nes {
    /* --- state (saved) --- */
    Cpu cpu; Ppu ppu; Apu apu; MapperRegs mr;
    uint8_t ram[2048], vram[4096], prg_ram[8192];
    uint8_t joy_buttons, joy_shift, joy_strobe, mapper_irq;
    /* --- runtime only --- */
    Cart cart; const Mapper *mapper;
    uint8_t *prg_map[4];      /* 8KB slots at $8000,$A000,$C000,$E000 */
    uint8_t *chr_map[8];      /* 1KB slots */
    uint8_t *nt_map[4];       /* 1KB nametable slots */
    uint32_t apu_cyc, frame_count;
    uint16_t frame[NES_SCREEN_W * NES_SCREEN_H];   /* column-major: [x*240 + (239-y)] RGB565 */
    int16_t audio[AUDIO_CAP]; int audio_n;
};

/* ---- bus ---- */
uint8_t nes_read_slow(Nes *n, uint16_t a);
void    nes_write_slow(Nes *n, uint16_t a, uint8_t v);
static inline uint8_t nes_read(Nes *n, uint16_t a) {
    if (a < 0x2000) return n->ram[a & 0x7FF];
    if (a >= 0x8000) return n->prg_map[(a >> 13) & 3][a & 0x1FFF];
    return nes_read_slow(n, a);
}
static inline void nes_write(Nes *n, uint16_t a, uint8_t v) {
    if (a < 0x2000) { n->ram[a & 0x7FF] = v; return; }
    nes_write_slow(n, a, v);
}

/* ---- top level (nes.c) ---- */
void nes_init(void);                 /* one-time table setup */
void nes_reset(Nes *n);
void nes_run_frame(Nes *n);

/* ---- cpu ---- */
void cpu_reset(Nes *n);
int  cpu_step(Nes *n);

/* ---- ppu ---- */
void    ppu_init_tables(void);
void    ppu_reset(Nes *n);
uint8_t ppu_reg_read(Nes *n, int reg);
void    ppu_reg_write(Nes *n, int reg, uint8_t v);
void    ppu_start_line(Nes *n);
void    ppu_hblank(Nes *n);

/* ---- apu ---- */
void    apu_init(void);
void    apu_reset(Nes *n);
void    apu_write(Nes *n, uint16_t a, uint8_t v);
uint8_t apu_read_status(Nes *n);
void    apu_run(Nes *n, int cycles);

/* ---- mappers ---- */
const Mapper *mapper_find(int id);
void nes_set_mirroring(Nes *n, int mode);
void nes_map_prg8(Nes *n, int slot, int bank);
void nes_map_prg16(Nes *n, int slot16, int bank);
void nes_map_prg32(Nes *n, int bank);
void nes_map_chr1(Nes *n, int slot, int bank);
void nes_map_chr2(Nes *n, int slot, int bank);
void nes_map_chr4(Nes *n, int slot, int bank);
void nes_map_chr8(Nes *n, int bank);

/* ---- rom ---- */
const char *rom_load(Nes *n, const char *path);   /* NULL on success, else error text */
void rom_unload(Nes *n);
void rom_save_sram(Nes *n);

/* ---- save states ---- */
void ss_path(const Nes *n, char *out, size_t cap);
bool ss_save(Nes *n, const char *path);
bool ss_load(Nes *n, const char *path);
#endif
