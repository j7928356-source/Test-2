#ifndef NES_MENU_H
#define NES_MENU_H
#include "nes_config.h"
#define ROM_DIR "sdmc:/roms/nes"
enum { MAIN_LOAD, MAIN_RECENT, MAIN_SETTINGS, MAIN_ABOUT, MAIN_EXIT };
enum { PAUSE_RESUME, PAUSE_SAVE, PAUSE_LOAD, PAUSE_RESET, PAUSE_BROWSER, PAUSE_EXIT };

/* All screens are blocking and draw on the bottom (console) screen. They return -1 if the
 * system asked the app to quit (HOME menu "close"). */
int  menu_main(void);
int  menu_browser(char *out_path, size_t cap);   /* 1 = chosen, 0 = back */
int  menu_recent(const Config *cfg, char *out_path, size_t cap);
void menu_settings(Config *cfg);
void menu_about(void);
void menu_message(const char *title, const char *msg);
int  menu_pause(const char *status);
#endif
