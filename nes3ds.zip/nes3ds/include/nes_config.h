#ifndef NES_CONFIG_H
#define NES_CONFIG_H
#include <stdint.h>
#define MAX_RECENT 8
enum { BTN_NONE, BTN_A, BTN_B, BTN_SELECT, BTN_START, BTN_TURBO_A, BTN_TURBO_B, BTN_COUNT };
enum { SCALE_1X, SCALE_ASPECT, SCALE_FULL, SCALE_COUNT };
typedef struct {
    uint32_t magic;
    uint8_t scale, frameskip, audio, lmap, rmap, showfps, nrecent, pad;
    char recent[MAX_RECENT][256];
} Config;
void config_defaults(Config *c);
void config_load(Config *c);
void config_save(const Config *c);
void recent_add(Config *c, const char *path);
#endif
