# NES Emulator for Nintendo 3DS (Old 3DS compatible)

Native homebrew (C99, devkitARM + libctru). Top screen = game, bottom screen = UI.

## Build
1. Install devkitPro with the 3DS toolchain: `dkp-pacman -S 3ds-dev` (sets `DEVKITARM`).
2. In this folder run `make` -> produces `nes3ds.3dsx` (+ `nes3ds.smdh`).
3. Copy `nes3ds.3dsx` to `sdmc:/3ds/` and launch from the Homebrew Launcher.

### CIA (optional, installable with FBI)
Needs `makerom` and `bannertool` in PATH, then `make cia` -> `nes3ds.cia`.
`cia.rsf` is hand-written and UNTESTED on hardware; if the CIA crashes on launch,
compare it against the `cia.rsf` in the devkitPro 3ds-examples template. The `.3dsx` is the supported path.

## Use
* Put ROMs in `sdmc:/roms/nes/` (`.nes`). Main menu: Load Game, Recent Games, Settings, About, Exit.
* Audio needs the DSP firmware dump at `sdmc:/3ds/dspfirm.cdc` (dump it with DSP1). Without it the emulator runs silent.
* Controls: D-Pad/Circle Pad = D-Pad, A = A, B = B, X = Select, Y = Start. L/R configurable (Turbo A/B, etc.).
* START opens the in-game menu: Resume, Save State, Load State, Reset, Return to Browser, Exit.
* Save states: `sdmc:/3ds/nes3ds/states/<rom>.st0`. Battery saves: `<rom>.sav` next to the ROM. Config: `sdmc:/3ds/nes3ds/config.bin`.
* Screen modes (Settings): 1:1 centered 256x240, NES aspect 8:7 (292 px), full width 400 px.

## Mappers
0 NROM, 1 MMC1, 2 UxROM, 3 CNROM, 4 MMC3, 7 AxROM. Add one by writing reset/write/sync(/scanline)
functions in `source/nes_mapper.c` and adding a row to the `mappers[]` table.

## Layout
Core (platform independent, no 3DS headers): `nes.c nes_cpu.c nes_ppu.c nes_apu.c nes_memory.c nes_mapper.c nes_rom.c nes_savestate.c`.
3DS layer: `main.c nes_input.c nes_render.c nes_audio.c nes_menu.c`. Everything shared is declared in `include/nes.h`.
Tests (host gcc): `tests/` - synthetic ROMs exercising CPU/NMI/PPU/mappers/save states.

## Design notes (performance)
* Scanline PPU, drawn straight into the 3DS native column-major RGB565 layout -> 1:1 display is one memcpy.
* CPU bus fast paths for RAM and PRG via 8 KB bank pointer tables (mappers only rebuild pointers).
* APU advances channels in batches; 2x oversampled mono 32 kHz; audio rate trimmed to 3DS vblank.
* Auto frameskip (max 2 consecutive) when a frame exceeds ~16.7 ms.
* Uses no New 3DS features (the 804 MHz mode is only enabled if a New 3DS is detected).

## Known limitations
* Not cycle-exact: mid-scanline scroll/palette changes, sprite-overflow quirks, DMC DMA stalls, open-bus details and
  color emphasis are simplified. Most licensed games for the supported mappers should run; some timing-sensitive titles may glitch.
* Only NTSC. No FDS/NSF, no 2-player input, one save-state slot.
* Written and tested on a PC only (core logic under ASan/UBSan). It has NOT been compiled with devkitARM or run on a 3DS.
